<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("ALTER TABLE `diafan_service_express_fields_category` DROP `add_new_items`;");
