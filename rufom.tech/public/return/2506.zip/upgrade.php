<?php
if (! defined('DIAFAN'))
{
	exit;
}
 
DB::query("ALTER TABLE {service_express_fields_category} ADD `add_new_items` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'добавить только новые данные, описанные в файле: 0 - нет, 1 - да';");
