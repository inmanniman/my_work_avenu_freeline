<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("UPDATE {users_role_perm} SET rewrite='order' WHERE rewrite='shop/order'");
DB::query("INSERT INTO {modules} (name, module_name, site, admin, title) VALUES ('order', 'shop', '1', '1', 'Заказы')");

$admin_order_id = DB::query_result("SELECT id FROM {admin} WHERE rewrite='shop/order' AND parent_id=0");
if($admin_order_id)
{
	$admin_order_id_1 = DB::query("INSERT INTO {admin} (parent_id, name, rewrite, act, sort) VALUES (%d, 'Заказы', 'order', '1', 1)", $admin_order_id);
	$admin_order_id_2 = DB::query("INSERT INTO {admin} (parent_id, name, rewrite, act, sort) VALUES (%d, 'Расширения для заказов', 'order/backend', '1', 2)", $admin_order_id);
	
	DB::query("INSERT INTO {admin_parents} (element_id, parent_id) VALUES (%d, %d)", $admin_order_id, $admin_order_id_1);
	DB::query("INSERT INTO {admin_parents} (element_id, parent_id) VALUES (%d, %d)", $admin_order_id, $admin_order_id_2);
	
	DB::query("UPDATE {admin} SET rewrite='order', count_children=2 WHERE id=%d", $admin_order_id);
}

DB::query("CREATE TABLE {shop_order_backend} (
`id` SMALLINT(5) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'идентификатор',
`name` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'название',
`backend` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'бэкенд',
`params` TEXT COMMENT 'серилизованные настройки',
`act` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'показывать на сайте: 0 - нет, 1 - да',
`sort` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'подрядковый номер для сортировки',
`list` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'выводить в списке',
`trash` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'запись удалена в корзину: 0 - нет, 1 - да',
PRIMARY KEY (id)
) CHARSET=utf8 COMMENT 'Расширения заказа'");

DB::query("CREATE TABLE {shop_order_backend_element} (
`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'идентификатор',
`order_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор заказа из таблицы {shop_order}',
`backend_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор расширения из таблицы {shop_order_backend}',
`type` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'тип - для разделения данных внутри бэкенда',
`value` TEXT COMMENT 'данные',
`trash` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'запись удалена в корзину: 0 - нет, 1 - да',
PRIMARY KEY (id)
) CHARSET=utf8 COMMENT 'Данные о заказе для бэкенда'");

DB::query("INSERT INTO {shop_order_backend} (name, backend, act, sort) VALUES ('Товарная накладная', 'packing_list', '1', 1)");

DB::query("UPDATE {config} SET value='kcaptcha' WHERE value='captcha' AND module_name='captcha'");
DB::query("UPDATE {config} SET name='backend' WHERE module_name='captcha' AND name='type'");

$admin_captcha_id = DB::query_result("SELECT id FROM {admin} WHERE rewrite='captcha' AND parent_id=0");
if($admin_captcha_id)
{
	DB::query("UPDATE {admin} SET count_children=0 WHERE id=%d", $admin_captcha_id);
	DB::query("DELETE FROM {admin} WHERE parent_id=%d", $admin_captcha_id);
	DB::query("DELETE FROM {admin_parents} WHERE parent_id=%d", $admin_captcha_id);
}

DB::query("RENAME TABLE {captcha} TO {captcha_qa};");
DB::query("RENAME TABLE {captcha_answers} TO {captcha_qa_answers};");

DB::query("DELETE FROM {captcha_qa} WHERE trash='0'");
DB::query("DELETE FROM {captcha_qa_answers} WHERE trash='0'");
DB::query("DELETE FROM {trash_parents} WHERE parent_id IN (SELECT id FROM {trash} WHERE module_name='captcha')");
DB::query("DELETE FROM {trash} WHERE module_name='captcha'");

$geomap_configs = DB::query_fetch_key_value("SELECT name, value FROM {config} WHERE module_name='geomap'", "name", "value");
if(! empty($geomap_configs["config"]) && ! empty($geomap_configs["backend"]))
{
	$geomap_config = unserialize($geomap_configs["config"]);
	foreach($geomap_config as $k => $v)
	{
		if(! preg_match('/^'.$geomap_configs["backend"].'/', $k))
		{
			$k = $geomap_configs["backend"].'_'.$k;
		}
		if(! isset($geomap_configs[$k]))
		{
			DB::query("INSERT INTO {config} (module_name, name, value) VALUES ('geomap', '%s', '%s')", $k, $v);
		}
	}
}

DB::query("INSERT INTO {config} (module_name, name, value) VALUES ('consultant', 'backend', 'jivosite')");