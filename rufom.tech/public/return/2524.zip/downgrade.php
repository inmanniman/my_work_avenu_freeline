<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("UPDATE {users_role_perm} SET rewrite='shop/order' WHERE rewrite='order'");
DB::query("DELETE FROM {modules} WHERE name='order'");

$admin_order_id = DB::query_result("SELECT id FROM {admin} WHERE rewrite='order' AND parent_id=0");
if($admin_order_id)
{
	DB::query("UPDATE {admin} SET rewrite='shop/order', count_children=0 WHERE id=%d", $admin_order_id);
	DB::query("DELETE FROM {admin} WHERE parent_id=%d", $admin_order_id);
	DB::query("DELETE FROM {admin_parents} WHERE parent_id=%d", $admin_order_id);
}
DB::query("DROP TABLE {shop_order_backend}");
DB::query("DROP TABLE {shop_order_backend_element}");


DB::query("UPDATE {config} SET name='type' WHERE module_name='captcha' AND name='backend'");
DB::query("UPDATE {config} SET value='captcha' WHERE value='kcaptcha' AND module_name='captcha'");

$admin_captcha_id = DB::query_result("SELECT id FROM {admin} WHERE rewrite='captcha' AND parent_id=0");
if($admin_captcha_id)
{
	$admin_captcha_id_1 = DB::query("INSERT INTO {admin} (parent_id, name, rewrite, act, sort) VALUES (%d, 'Captcha', 'captcha', '1', 1)", $admin_captcha_id);
	$admin_captcha_id_2 = DB::query("INSERT INTO {admin} (parent_id, name, rewrite, sort) VALUES (%d, 'Настройки', 'captcha/config',  2)", $admin_captcha_id);
	
	DB::query("INSERT INTO {admin_parents} (element_id, parent_id) VALUES (%d, %d)", $admin_captcha_id, $admin_captcha_id_1);
	DB::query("INSERT INTO {admin_parents} (element_id, parent_id) VALUES (%d, %d)", $admin_captcha_id, $admin_captcha_id_2);
	
	DB::query("UPDATE {admin} SET rewrite='captcha', count_children=2 WHERE id=%d", $admin_captcha_id);
}

DB::query("RENAME TABLE {captcha_qa} TO {captcha};");
DB::query("RENAME TABLE {captcha_qa_answers} TO {captcha_answers};");

DB::query("DELETE FROM {consultant} WHERE name='backend' AND module_name='consultant'");