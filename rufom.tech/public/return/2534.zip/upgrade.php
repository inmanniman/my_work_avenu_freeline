<?php
if (! defined('DIAFAN'))
{
	exit;
}

// интеграция ЛК - начало
DB::query("UPDATE {admin} SET name='Служба поддержки' WHERE rewrite='account/support'");
DB::query("UPDATE {admin} SET name='Поиск веб-мастера' WHERE rewrite='account/projects'");
DB::query("ALTER TABLE {addons} ADD `cat_name` VARCHAR(100) NOT NULL DEFAULT '' COMMENT 'название категории'");
DB::query("ALTER TABLE {addons} ADD `price` DOUBLE NOT NULL default '0' COMMENT 'цена'");
DB::query("ALTER TABLE {addons} ADD `price_month` DOUBLE NOT NULL default '0' COMMENT 'цена по подписке'");
DB::query("ALTER TABLE {addons} ADD `available_subscription` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'доступно по подписке: 0 - нет, 1 - да'");
DB::query("ALTER TABLE {addons} ADD `buy` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'куплено дополнение: 0 - нет, 1 - да'");
DB::query("ALTER TABLE {addons} ADD `subscription` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'время окончания подписки на дополнение в формате UNIXTIME'");
DB::query("ALTER TABLE {addons} ADD `file_rewrite` VARCHAR( 255 ) NOT NULL DEFAULT '' COMMENT 'ссылка на страницу дополнения в административной части сайта'");
// интеграция ЛК - конец
