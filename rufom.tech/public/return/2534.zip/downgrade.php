<?php
if (! defined('DIAFAN'))
{
	exit;
}

// интеграция ЛК - начало
DB::query("ALTER TABLE {addons} DROP cat_name;");
DB::query("ALTER TABLE {addons} DROP price;");
DB::query("ALTER TABLE {addons} DROP price_month;");
DB::query("ALTER TABLE {addons} DROP available_subscription;");
DB::query("ALTER TABLE {addons} DROP buy;");
DB::query("ALTER TABLE {addons} DROP subscription;");
DB::query("ALTER TABLE {addons} DROP file_rewrite;");
// интеграция ЛК - конец
