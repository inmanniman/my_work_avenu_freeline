<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("DELETE FROM {config} WHERE `module_name`='service_express';");
DB::query("ALTER TABLE {service_express_fields_category} ADD `act_items` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'опубликовать данные, описанные в файле: 0 - нет, 1 - да';");
DB::query("ALTER TABLE {service_express_fields_category} ADD `menu_cat_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор категории из таблицы {menu_category}';");

if(defined('EMAIL_CONFIG') && EMAIL_CONFIG)
{
	$this->diafan->configmodules("email", 'postman', 0, 0, EMAIL_CONFIG);
}
if(defined('SMTP_MAIL') && SMTP_MAIL)
{
	$this->diafan->configmodules("smtp_mail", 'postman', 0, 0, (SMTP_MAIL ? 1 : 0));
}
if(defined('SMTP_HOST') && SMTP_HOST)
{
	$this->diafan->configmodules("smtp_host", 'postman', 0, 0, SMTP_HOST);
}
if(defined('SMTP_LOGIN') && SMTP_LOGIN)
{
	$this->diafan->configmodules("smtp_login", 'postman', 0, 0, SMTP_LOGIN);
}
if(defined('SMTP_PASSWORD') && SMTP_PASSWORD)
{
	$this->diafan->configmodules("smtp_password", 'postman', 0, 0, SMTP_PASSWORD);
}
if(defined('SMTP_PORT') && SMTP_PORT)
{
	$this->diafan->configmodules("smtp_port", 'postman', 0, 0, SMTP_PORT);
}
if(defined('SMS') && SMS)
{
	$this->diafan->configmodules("sms", 'postman', 0, 0, (SMS ? 1 : 0));
	$this->diafan->configmodules("sms_provider", 'postman', 0, 0, 'smsc');
}
if(defined('SMS_KEY') && SMS_KEY)
{
	$this->diafan->configmodules("smsc_psw", 'postman', 0, 0, SMS_KEY);
}
if(defined('SMS_ID') && SMS_ID)
{
	$this->diafan->configmodules("smsc_login", 'postman', 0, 0, SMS_ID);
}
if(defined('SMS_SIGNATURE') && SMS_SIGNATURE)
{
	$this->diafan->configmodules("smsc_signature", 'postman', 0, 0, SMS_SIGNATURE);
}

Custom::inc('includes/config.php');
$config = new Config();
$config->save(array('MOD_DEVELOPER_POST' => false), $this->diafan->_languages->all);
