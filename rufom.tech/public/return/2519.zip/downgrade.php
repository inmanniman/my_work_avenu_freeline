<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("ALTER TABLE {inserts_site_rel} DROP `trash`;");
DB::query("ALTER TABLE {inserts} DROP `date_start`;");
DB::query("ALTER TABLE {inserts} DROP `date_finish`;");
DB::query("ALTER TABLE {inserts} DROP `timeedit`;");
DB::query("ALTER TABLE {inserts} DROP `admin_id`;");
