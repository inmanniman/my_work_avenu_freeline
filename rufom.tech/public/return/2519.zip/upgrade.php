<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("ALTER TABLE {inserts_site_rel} ADD `trash` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'запись удалена в корзину: 0 - нет, 1 - да'");
DB::query("ALTER TABLE {inserts} ADD `date_start` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'дата начала показа'");
DB::query("ALTER TABLE {inserts} ADD `date_finish` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'дата окончания показа'");
DB::query("ALTER TABLE {inserts} ADD `timeedit` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'время последнего изменения в формате UNIXTIME'");
DB::query("ALTER TABLE {inserts} ADD `admin_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'пользователь из таблицы {users}, добавивший или первый отредктировавший товар в административной части'");
