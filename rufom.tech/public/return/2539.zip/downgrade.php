<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("DROP TABLE {shop_cashregister}");

DB::query("DELETE FROM {modules} WHERE name='cashregister'");

$admin = DB::query_fetch_array("SELECT id, parent_id FROM {admin} WHERE rewrite='cashregister'");
if($admin)
{
	DB::query("DELETE FROM {admin_parents} WHERE element_id=%d", $admin["id"]);
	DB::query("DELETE FROM {admin} WHERE rewrite='cashregister'");
	if($admin["parent_id"])
	{
		DB::query("UPDATE {admin} SET count_children=count_children-1 WHERE id=%d", $admin["parent_id"]);
	}
}

$admin = DB::query_fetch_array("SELECT id, parent_id FROM {admin} WHERE rewrite='cashregister/config'");
if($admin)
{
	DB::query("DELETE FROM {admin_parents} WHERE element_id=%d", $admin["id"]);
	DB::query("DELETE FROM {admin} WHERE rewrite='cashregister/config'");
	if($admin["parent_id"])
	{
		DB::query("UPDATE {admin} SET count_children=count_children-1 WHERE id=%d", $admin["parent_id"]);
	}
}

DB::query("DELETE FROM {config} WHERE module_name='cashregister'");

$admin = DB::query_fetch_array("SELECT id, parent_id FROM {admin} WHERE rewrite='order/config'");
if($admin)
{
	DB::query("DELETE FROM {admin_parents} WHERE element_id=%d", $admin["id"]);
	DB::query("DELETE FROM {admin} WHERE rewrite='order/config'");
	if($admin["parent_id"])
	{
		DB::query("UPDATE {admin} SET count_children=count_children-1 WHERE id=%d", $admin["parent_id"]);
	}
}


DB::query("ALTER TABLE {addons} DROP `tag`");


// Для DIAFAN.CMS 6.0.11.0
