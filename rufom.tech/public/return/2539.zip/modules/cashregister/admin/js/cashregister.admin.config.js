/**
 * @package    DIAFAN.CMS
 * @author     diafan.ru
 * @version    6.0
 * @license    http://www.diafan.ru/license.html
 * @copyright  Copyright (c) 2003-2019 OOO «Диафан» (http://www.diafan.ru/)
 */

$(".js_btn_test").click(function (e) {
    e.preventDefault();

    diafan_ajax.init({
        data: {
            action: 'test',
            module: 'cashregister'
        },
        success: function (response) {
            if (response.data)
            {
                $("#test_check").text(prepare(response.data)).addClass('ok');
            }
            if (response.error)
            {
                $("#test_check").text(prepare(response.error)).addClass('error');
            }
        }
    });
});