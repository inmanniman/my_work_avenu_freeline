<?php
if (! defined('DIAFAN'))
{
	exit;
}


DB::query("CREATE TABLE {shop_cashregister} (
`master_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'главный идентификатор в формате UNIXTIME',
`slave_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'вторичный идентификатор в интервале master_id',
`id` TEXT COMMENT 'объединенный идентификатор',
`type` ENUM('presell', 'sell', 'refund') NOT NULL DEFAULT 'sell' COMMENT 'тип чека: presell - предоплата, sell - полная оплата, refund - возврат',
`important` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'защита от повторого чека: 0 - нет, 1 - да',
`order_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор заказа из таблицы {shop_orders}',
`external_id` VARCHAR(255) NOT NULL DEFAULT '',
`auto` ENUM('0', '1') NOT NULL DEFAULT '1' COMMENT 'метод отправки чека: 0 - ручной, 1 - автоматический',
`timeedit` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'время последнего изменения в формате UNIXTIME',
`timesent` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'время отправки чека в формате UNIXTIME',
`status` ENUM('0', '1', '2') NOT NULL DEFAULT '0' COMMENT 'отчет об отправки чека: 0 - не отправлено, 1 - отправлено, 2 - ошибка отправления',
`error` TEXT COMMENT 'отчет об ошибке отправления',
`trace` TEXT COMMENT 'трассировка отправления',
PRIMARY KEY (`master_id`, `slave_id`)
) CHARSET=utf8 COMMENT 'Чеки для онлайн кассы'");

DB::query("INSERT INTO {modules} (name, module_name, site, admin, title) VALUES ('cashregister', 'shop', '1', '1', 'Онлайн касса')");

$admin_id = DB::query_result("SELECT id FROM {admin} WHERE rewrite='payment' AND parent_id=0");
if(! $admin_id)
{
	$admin_id = DB::query("INSERT INTO {admin} (name, rewrite, group_id, sort, act) VALUES ('Оплата', 'payment', 4, 14, '1')");
}
$admin_id_new = DB::query("INSERT INTO {admin} (name, rewrite, sort, act, parent_id) VALUES ('Он-лайн касса', 'cashregister', 4, '1', %d)", $admin_id);

DB::query("INSERT INTO {admin_parents} (element_id, parent_id) VALUES (%d, %d)", $admin_id_new, $admin_id);

$admin_id_new = DB::query("INSERT INTO {admin} (name, rewrite, sort, parent_id) VALUES ('Настройки', 'cashregister/config', 5, %d)", $admin_id);

DB::query("INSERT INTO {admin_parents} (element_id, parent_id) VALUES (%d, %d)", $admin_id_new, $admin_id);

DB::query("UPDATE {admin} SET count_children=count_children+2 WHERE id=%d", $admin_id);

DB::query("INSERT INTO {config} (name, module_name, value) VALUES ('defer', 'cashregister', '1')");
DB::query("INSERT INTO {config} (name, module_name, value) VALUES ('auto_send', 'cashregister', '1')");

$admin_id = DB::query_result("SELECT id FROM {admin} WHERE rewrite='order' AND parent_id=0");
if($admin_id)
{
	$admin_id_new = DB::query("INSERT INTO {admin} (name, rewrite, sort, parent_id) VALUES ('Настройки', 'order/config', 5, %d)", $admin_id);

	DB::query("INSERT INTO {admin_parents} (element_id, parent_id) VALUES (%d, %d)", $admin_id_new, $admin_id);
}


// $new_values = array('MOD_PROTECTED' => 'false');
// Custom::inc('includes/config.php');
// Config::save($new_values, $this->diafan->_languages->all);


DB::query("ALTER TABLE {addons} ADD `tag` VARCHAR( 255 ) NOT NULL DEFAULT '' COMMENT 'тег дополнения'");


// Для DIAFAN.CMS 6.0.11.0
