<?php
if (! defined('DIAFAN'))
{
	exit;
}

// DB::query("ALTER TABLE {ab} ADD `import` ENUM( '0', '1' ) NOT NULL DEFAULT '0' COMMENT 'элемент только что импортирован: 0 - нет, 1 - да'");
// DB::query("ALTER TABLE {ab} ADD `import_id` VARCHAR(100) NOT NULL DEFAULT '' COMMENT 'собственный идентификатор элемента при импорте'");
// DB::query("ALTER TABLE {ab_category} ADD `import` ENUM( '0', '1' ) NOT NULL DEFAULT '0' COMMENT 'категория только что импортирован: 0 - нет, 1 - да'");
// DB::query("ALTER TABLE {ab_category} ADD `import_id` VARCHAR(100) NOT NULL DEFAULT '' COMMENT 'собственный идентификатор категории при импорте'");
// DB::query("ALTER TABLE {ab} ADD `sort` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'подрядковый номер для сортировки'");
