<?php
if (! defined('DIAFAN'))
{
	exit;
}

// DB::query("ALTER TABLE {ab} DROP `import`;");
// DB::query("ALTER TABLE {ab} DROP `import_id`;");
// DB::query("ALTER TABLE {ab_category} DROP `import`;");
// DB::query("ALTER TABLE {ab_category} DROP `import_id`;");
// DB::query("ALTER TABLE {ab} DROP `sort`;");
