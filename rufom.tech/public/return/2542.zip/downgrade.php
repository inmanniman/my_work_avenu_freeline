<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("ALTER TABLE {custom} DROP `addon_id`");

// Для DIAFAN.CMS 6.0.11.3
