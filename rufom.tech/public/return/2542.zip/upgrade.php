<?php
if (! defined('DIAFAN'))
{
	exit;
}


DB::query("ALTER TABLE {custom} ADD `addon_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор дополнения'");


$variable = array('payment_success_text', 'payment_fail_text');
$languages = $this->diafan->_languages->all;
if(count($languages) > 1)
{
	if($site_ids = DB::query_fetch_value("SELECT id FROM {site} WHERE module_name='%h' AND trash='0'", 'shop', "id"))
	{
		$site_ids_count = count($site_ids);
		foreach ($variable as $value)
		{
			$new_values = array();
			foreach ($site_ids as $site_id)
			{
				$site_id = $site_ids_count > 1 ? $site_id : 0;
				$default = false;
				foreach ($languages as $language)
				{
					$val = $this->diafan->configmodules($value, "shop", $site_id, $language["id"]);
					if($language["base_site"] == 1)
					{
						$default = $val;
					}
					$new_values[$site_id][$language["id"]] = $this->diafan->configmodules($value, "shop", $site_id, $language["id"]);
				}
				foreach ($languages as $language)
				{
					if(! empty($new_values[$site_id][$language["id"]])) continue;
					$new_values[$site_id][$language["id"]] = $default;
				}
			}
			foreach($new_values as $site_id => $rows)
			{
				foreach($rows as $language_id => $val)
				{
					$this->diafan->configmodules($value, "shop", $site_id, $language_id, $val);
				}
			}
		}
	}
}


// Для DIAFAN.CMS 6.0.11.3
