/*DIAFAN.CMS*/
$('input[type=number], input.number, input.js_number').keydown(function (evt) {
	evt = (evt) ? evt : ((window.event) ? event : null);

	if (evt) {
		var elem = (evt.target)
		? evt.target
		: (
		evt.srcElement
			? evt.srcElement
			: null
		);

		if (elem) {
		var charCode = evt.charCode
			? evt.charCode
			: (evt.which
			? evt.which
			: evt.keyCode
			);

		if ((charCode < 32 ) ||
			(charCode > 36 && charCode < 41) ||
			(charCode > 44 && charCode < 47) ||
			(charCode > 95 && charCode < 106) ||
			(charCode > 47 && charCode < 58) || charCode == 188 || charCode == 191 || charCode == 190 || charCode == 110 || charCode == 86 || charCode == 67) {
			return true;
		}
		else {
			return false;
		}
		}
	}
});

$('input[type=tel]').mask('+9999 999 9999');

var diafan_ajax = {
	data: false,
	url: false,
	cache: true,
	before: false,
	error: false,
	success: false,
	complete: false,
	done: false,
	fail: false,
	timeout: false,
	timeOut: (30 * 1000),
  timerId: 0,
	init: function(config){
		if (config.data) {
			this.data = config.data;
		} else {
			this.data = {};
		}
		if (config.url) {
			this.url = config.url;
		} else {
			this.url = window.location.href;
		}
		if (! ("cache" in config)) {
			this.cache = this.cache;
		} else {
			this.cache = !! config.cache;
		}
		if (config.before) {
			this.before = config.before;
		} else {
			this.before = (function(jqXHR, settings){});
		}
		if (config.error) {
			this.error = config.error;
		} else {
			this.error = (function(jqXHR, textStatus, errorThrown){});
		}
		if (config.success) {
			this.success = config.success;
		} else {
			this.success = (function(response){});
		}
		if (config.complete) {
			this.complete = config.complete;
		} else {
			this.complete = (function(jqXHR, textStatus){});
		}
		if (config.fail) {
			this.fail = config.fail;
		} else {
			this.fail = (function(){});
		}
		if (config.done) {
			this.done = config.done;
		} else {
			this.done = (function(){});
		}
		if (config.timeout) {
			this.timeout = config.timeout;
		} else {
			this.timeout = (function(data, timeout){});
		}
		this.data.check_hash_user = $('.check_hash_user').text();
		this.data = {"_data_":JSON.stringify(this.data)};
		return $.ajax({
			url: diafan_ajax.url,
			type: 'POST',
			cache: diafan_ajax.cache,
			data: diafan_ajax.data,
			beforeSend:(function (jqXHR, settings) {
				clearTimeout(diafan_ajax.timerId);
				diafan_ajax.timeOut = (((window.MAX_EXECUTION_TIME || 30) * 1000) + (10 * 1000));
				diafan_ajax.timerId = setTimeout(function() {
					$(document).trigger('diafan_ajax.timeout', [ diafan_ajax.data, diafan_ajax.timeOut ]);
					diafan_ajax.timeout(diafan_ajax.data, diafan_ajax.timeOut);
				}, diafan_ajax.timeOut);
				diafan_ajax.before(jqXHR, settings);
			}),
			error:(function (jqXHR, textStatus, errorThrown) {
				clearTimeout(diafan_ajax.timerId);
				diafan_ajax.before(jqXHR, textStatus, errorThrown);
			}),
			success:(function (data, textStatus, jqXHR) {
				clearTimeout(diafan_ajax.timerId);
				try {
					var response = $.parseJSON(data);
				} catch(err){
					$('body').append(data);
					$('.diafan_div_error').css('left', $(window).width()/2 - $('.diafan_div_error').width()/2);
					$('.diafan_div_error').css('top', $(window).height()/2 - $('.diafan_div_error').height()/2 + $(document).scrollTop());
					$('.diafan_div_error_overlay').css('height', $('body').height());
					return false;
				}
				if (response.hash) {
					$('input[name=check_hash_user]').val(response.hash);
					$('.check_hash_user').text(response.hash);
				}
				if(response.redirect) {
					window.location.href = prepare(response.redirect);
				}
				if(response.profiler) {
					$(".devoloper_profiling[ajax]").remove();
					$(".devoloper_profiler[ajax]").remove();
					$('body').append(prepare(response.profiler));
					delete response.profiler;
				}
				diafan_ajax.success(response);
			}),
			complete:(function (jqXHR, textStatus) {
				clearTimeout(diafan_ajax.timerId);
				diafan_ajax.complete(jqXHR, textStatus);
			}),
		}).done(function () {
			clearTimeout(diafan_ajax.timerId);
			diafan_ajax.done();
		}).fail(function () {
			clearTimeout(diafan_ajax.timerId);
			diafan_ajax.fail();
		});
	}
}

$(".timecalendar").each(function () {
	if ($(this).attr('showtime') == "true") {
		$(this).datetimepicker({
			dateFormat:'dd.mm.yy',
			timeFormat:'hh:mm',
			language: 'ru',
		}).mask('99.99.9999 99:99');
	}
	else if($(this).attr('hideYear') == "true")
	{
		$(this).datepicker({
		dateFormat:'dd.mm'
		}).mask('99.99');
	}
	else{
		$(this).datepicker({
		dateFormat:'dd.mm.yy'
		}).mask('99.99.9999');
	}
});

if ($('input[name=check_hash_user]').length && $('input[name=check_hash_user]').val() != $('.check_hash_user').text()) {
	$('input[name=check_hash_user]').val($('.check_hash_user').text());
}

$('select.redirect').change(function () {
	var path = $(this).attr("rel");
	if ($(this).val()) {
		path = path + $(this).attr("name") + $(this).val() + '/';
	}
	window.location.href = path;
});

$(document).tooltip();

function prepare(string) {
	string = str_replace('&lt;', '<', string);
	string = str_replace('&gt;', '>', string);
	string = str_replace('&amp;', '&', string);
	return string;
}

function str_replace(search, replace, subject, count) {
	f = [].concat(search),
		r = [].concat(replace),
		s = subject,
		ra = r instanceof Array, sa = s instanceof Array;
	s = [].concat(s);
	if (count) {
		this.window[count] = 0;
	}
	for (i = 0, sl = s.length; i < sl; i++) {
		if (s[i] === '') {
			continue;
		}
		for (j = 0, fl = f.length; j < fl; j++) {
			temp = s[i] + '';
			repl = ra ? (r[j] !== undefined ? r[j] : '') : r[0];
			s[i] = (temp).split(f[j]).join(repl);
			if (count && s[i] !== temp) {
				this.window[count] += (temp.length - s[i].length) / f[j].length;
			}
		}
	}
	return sa ? s : s[0];
}
function htmlentities(s) {
	var div = document.createElement('div');
	var text = document.createTextNode(s);
	div.appendChild(text);
	return div.innerHTML;
}

// Временный редирект с закладки "Импорт/экспорт" модуля "Интернет магарин" на закладку "Импорт/экспорт" модуля "Модули и БД"
$(".tabs a.tabs__item").click(function (event) {
	event = event || window.event;
	if(event.ctrlKey || event.altKey || event.shiftKey) return true;
	event.preventDefault ? event.preventDefault() : (event.returnValue=false);
	var url = $(this)[0],
			href = url.href;
	if(pathname = url.pathname)
	{
		var arr = pathname.split('/');
		var index = arr.indexOf('importexport');
		if(index != -1)
		{
			pathname = '';
			arr.every(function(item, i) {
				if(i == (index - 1)) item = 'service';
				if(i == index) item = 'express';
				pathname += item + '/';
				if(i == index) return false;
				else return true;
			});
		}
		href = url.protocol+'//'+url.hostname;
		if(url.port) href += ':'+url.port;
		if(pathname) href += pathname;
		if(url.search) href += url.search;
		if(url.hash) href += url.hash;
	}
	document.location.href = href; // document.location.replace(href);
});

var diafan_action = {
	inArray: null,
  timeOut: 100,
  timerId: 0,
	self: {},
	informer: {
		object: {},
		class: 'informer',
		reset: true,
		set: function(content) {
			content = content || '';
			var informer = diafan_action.informer.object;
			if (! informer.length)
			{
				if (diafan_action.self.length && diafan_action.informer.class != '') {
					informer = diafan_action.self.prev('.' + diafan_action.informer.class);
					if (! informer.length)
					{
						diafan_action.self.before('<div class="' + diafan_action.informer_class + '"></div>');
						informer = diafan_action.self.prev('.' + diafan_action.informer_class);
					}
				}
			}
			if(informer.length)
			{
				informer.html(content); //informer.contents().remove(); informer.append(content);
				return true;
			}
			else return false;
		}
	},
	informer_class: 'informer',
	response: false,
	continue: false,
	success: false,
  error: false,
	config: false,
	ajax: diafan_ajax,
  init: function(config) {
		if (config.self) this.self = config.self;
		if (config.informer) {
			if (config.informer.object) this.informer.object = config.informer.object;
			if (config.informer.class) this.informer.class = config.informer.class;
			if ('reset' in config.informer) this.informer.reset = config.informer.reset;
		}
		if (config.response) this.response = config.response;
		else this.response = (function(response){});
		if (config.continue) this.continue = config.continue;
    else this.continue = (function(response){});
		if (config.success) this.success = config.success;
    else this.success = (function(response){});
    if (config.error) this.error = config.error;
    else this.error = (function(response){});
		if (config.config) this.config = config.config;
    else this.config = {};

		if(! this.config.success)
		{
			this.config["success"] = (function(response) {
				if(diafan_action.response(response) === false) {
					return false;
				}
				if (response.informer) {
					diafan_action.informer.set(prepare(response.informer));
        } else {
					if (diafan_action.informer.reset) diafan_action.informer.set();
				}
        if (response.result == 'success') {
					diafan_action.success(response);
				}
        if (response.result == 'error') {
					diafan_action.error(response);
        }
				if (response.result == 'continue') {
					if(diafan_action.continue(response) !== false) {
						diafan_action.timerId = setTimeout(function() {
							diafan_action.ajax.init(diafan_action.config);
						}, diafan_action.timeOut);
					}
        }
      });
		}
		this.ajax.init(this.config);
  }
};
// alternative method: переопределяем метод diafan_action.inArray
if ([].indexOf) { diafan_action.inArray = function(array, value) { return array.indexOf(value); } }
else { diafan_action.inArray = function(array, value) { for (var i = 0; i < array.length; i++) { if (array[i] === value) return i; } return -1; } }

(function( $ ) {
  $.fn.getData = function() {
    var data = {}, self = this;
    if(! this || ! this.length)
    {
      return data;
    }
    $("input, select", this).each(function(index, element) {
  		var name = $(this).attr('name'),
  				type = $(this).attr('type'),
          tagName = $(element)[0].tagName,
          value = $(element).val();
      tagName = tagName.toUpperCase();
      if(! tagName || ! name)
      {
        return true;
      }
  		if(tagName == 'INPUT' && (! type || type == 'submit' || type == 'button'))
  		{
  			return true;
  		}
      if(tagName == 'INPUT' && type == 'checkbox')
      {
        if($(element).prop('checked'))
        {
          if($(element).val()) value = $(element).val();
          else value = $(element).prop('checked');
        }
        else value = '';
      }
      if(tagName == 'INPUT' && type == 'radio')
      {
        var radio = $("input[name='"+name+"']:checked", self);
        if (radio.length) value = radio.val();
        else value = '';
      }

      var levels = name.match( /(\[[A-Za-z0-9_]*\])/gi );
      if (levels)
      {
        var indx = name.search( /\[/ ),
            fld = name.substring(0, indx),
            field = fld;
        levels.forEach(function(item, index, array) {
          var level = item.replace( /\[([A-Za-z0-9_]*)\]/gi, '$1' );
          field = field + '[' + level + ']';
        });
        if (name == field && fld.length > 0)
        {
          if ( ! (fld in data) )
          {
            data[fld] = {};
          }
          var dt = data[fld];
          levels.forEach(function(item, index, array) {
            var level = item.replace( /\[([A-Za-z0-9_]*)\]/gi, '$1' );
            if ( ! (level in dt) )
            {
              if (! level.length)
              {
                var counter = 0;
                for (var key in dt) {
                  counter++;
                }
                level = String(counter);
              }
              dt[level] = {};
            }
            if (index < (array.length - 1)) dt = dt[level];
            else dt[level] = value;
          });
        }
        else data[name] = value;
      }
      else data[name] = value;
  	});
    return data; // return this;
  };
})( jQuery );

(function( $ ) {
  $.fn.clicker = function() {
    if(! this || ! this.length)
    {
      return this;
    }
		var link = this[0];
    var linkEvent = null;
    if (document.createEvent) {
      linkEvent = document.createEvent('MouseEvents');
      linkEvent.initEvent('click', true, true);
      link.dispatchEvent(linkEvent);
    }
    else if (document.createEventObject) {
      linkEvent = document.createEventObject();
      link.fireEvent('onclick', linkEvent);
    }
		return this;
  };
})( jQuery );

$('.depend_field').each(function(){
	var s = $(this);
	var depend = $(this).attr('depend').split(',');

	$.each(depend, function(){
		var f = function() {
			var show = true;
			$.each(depend, function(){
				var da = this.split('|');
				if (da.length > 1) {
					show = false;
					$.each(da, function(){
						var val = this.split('=', 2);
						if (val.length > 1) {
							if ($('input[name='+val[0]+']').is(':checked') || $('select[name='+val[0]+']').val() == val[1]) {
								show = true;
							}
						}
						else
						{
							if ($('input[name='+val[0]+']').is(':checked') || $('select[name='+val[0]+']').val()) {
								show = true;
							}
						}
					});
				}
				else
				{
					$.each(da, function(){
						var val = this.split('=', 2);
						if (val.length > 1) {
							if (! $('input[name='+val[0]+']').is(':checked') && ! ($('select[name='+val[0]+']').val() == val[1])) {
								show = false;
							}
						}
						else
						{
							if (! $('input[name='+val[0]+']').is(':checked') && ! $('select[name='+val[0]+']').val()) {
								show = false;
							}
						}
					});
				}
			});
			if (show) {
				s.show();
			}
			else
			{
				s.hide();
			}
		}
		var da = this.split('|');
		var d = '';
		$.each(da, function(){
			var val = this.split('=', 2);
			if (d) {
				d = d + ',';
			}
			d = d + 'input[name=' + val[0] + '],select[name=' + val[0] + ']';
		});
		$(document).on("change", d, f); // $(d).change(f);
		f();
	});
});
