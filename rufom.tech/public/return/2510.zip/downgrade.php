<?php
if (! defined('DIAFAN'))
{
	exit;
}

// DB::query("ALTER TABLE `diafan_service_express_fields_category` DROP `add_new_items`;");
//
// DB::query("DELETE FROM {admin} WHERE `rewrite`='images/config' AND `parent_id`='7';");
// DB::query("DELETE FROM {config} WHERE `module_name`='images' AND name='hash_compare';");
// DB::query("ALTER TABLE `diafan_images` DROP `hash`;");

DB::query("ALTER TABLE `diafan_service_express_fields_category` DROP `act_items`;");
DB::query("ALTER TABLE `diafan_service_express_fields_category` DROP `menu_cat_id`;");
