<?php
if (! defined('DIAFAN'))
{
	exit;
}

// DB::query("ALTER TABLE {service_express_fields_category} ADD `add_new_items` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'добавить только новые данные, описанные в файле: 0 - нет, 1 - да';");
//
// DB::query("INSERT INTO {admin} (`id`, `parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`) VALUES (NULL, (SELECT e.id  FROM {admin} AS e WHERE e.`rewrite` LIKE 'images' ORDER BY id ASC LIMIT 1), '0', '5', 'Настройки', 'images/config', '0', '0', '', '1', '');");
// DB::query("INSERT INTO {config} (`id`, `module_name`, `name`, `lang_id`, `value`, `site_id`) VALUES (NULL, 'images', 'hash_compare', '0', '1', '0');");
// DB::query("ALTER TABLE {images} ADD `hash` CHAR(32) NOT NULL DEFAULT '' COMMENT 'хэш файла'");
//
// Custom::inc('includes/config.php');
// $config = new Config();
// $config->save(array('MOD_DEVELOPER_PROFILER' => false), $this->diafan->_languages->all);

DB::query("DELETE FROM {config} WHERE `module_name`='service_express';");
// DB::query("DELETE FROM {config} WHERE `module_name`='service_express' AND `name` IN ('Service_inc_busy_proc_uid', 'Service_express_export_file_export', 'Service_express_export_module_name', 'Service_express_export_pos', 'Service_admin_express_import_ftell', 'Service_admin_express_import_part', 'Service_admin_express_import_table_elements', 'Service_admin_express_import_file_name', 'Service_admin_express_import_files', 'Service_admin_express_import_defer_files', 'Service_express_import_file_errors_log', 'Service_express_import_last_cat_id');");
DB::query("ALTER TABLE {service_express_fields_category} ADD `act_items` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'опубликовать данные, описанные в файле: 0 - нет, 1 - да';");
DB::query("ALTER TABLE {service_express_fields_category} ADD `menu_cat_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор категории из таблицы {menu_category}';");

Custom::inc('includes/config.php');
$config = new Config();
$config->save(array('MOD_DEVELOPER_POST' => false), $this->diafan->_languages->all);
