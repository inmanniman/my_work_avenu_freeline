<?php
if (! defined('DIAFAN'))
{
	exit;
}
DB::query("DELETE FROM {config} WHERE `module_name`='service' AND name='express_preview_enable';");
DB::query("DELETE FROM {config} WHERE `module_name`='service' AND name='express_count_part';");

DB::query("DELETE FROM {admin} WHERE `rewrite`='service/config' AND `parent_id`='1';");
DB::query("DELETE FROM {admin} WHERE `rewrite`='service/express/fields' AND `parent_id`='1';");
DB::query("DELETE FROM {admin} WHERE `rewrite`='service/express/export' AND `parent_id`='1';");
DB::query("DELETE FROM {admin} WHERE `rewrite`='service/express/import' AND `parent_id`='1';");
DB::query("DELETE FROM {admin} WHERE `rewrite`='service/express' AND `parent_id`='1';");

DB::query("DROP TABLE IF EXISTS {service_express_fields};");
DB::query("DROP TABLE IF EXISTS {service_express_fields_category};");

DB::query("ALTER TABLE {sessions} CHANGE `user_agent` `user_agent` VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'браузер пользователя';");
