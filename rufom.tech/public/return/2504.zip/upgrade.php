<?php
if (! defined('DIAFAN'))
{
	exit;
}
DB::query("INSERT INTO {admin} (`id`, `parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`) VALUES (NULL, '1', '0', '5', 'Экспорт/импорт', 'service/express', '1', '0', '', '4', '');");
DB::query("INSERT INTO {admin} (`id`, `parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`) VALUES (NULL, '1', '0', '5', 'Импорт', 'service/express/import', '0', '0', '', '5', '');");
DB::query("INSERT INTO {admin} (`id`, `parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`) VALUES (NULL, '1', '0', '5', 'Экспорт', 'service/express/export', '0', '0', '', '6', '');");
DB::query("INSERT INTO {admin} (`id`, `parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`) VALUES (NULL, '1', '0', '5', 'Сохраненные импорт/экспорт', 'service/express/fields', '0', '0', '', '7', '');");
DB::query("INSERT INTO {admin} (`id`, `parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`) VALUES (NULL, '1', '0', '5', 'Настройки', 'service/config', '0', '0', '', '8', '');");

DB::query("CREATE TABLE {service_express_fields} (`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'идентификатор',
`name` VARCHAR(250) NOT NULL DEFAULT '' COMMENT 'название', `cat_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор описания файла из таблицы {service_express_fields_category}', `type` VARCHAR(20) NOT NULL DEFAULT '' COMMENT 'тип', `params` TEXT COMMENT 'серилизованные данные о поле', `required` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'серилизованные данные о поле', `sort` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'выдавать ошибку, если поле не заполнено: 0 - нет, 1 - да', `trash` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'запись удалена в корзину: 0 - нет, 1 - да', PRIMARY KEY (id)) CHARSET=utf8 COMMENT 'Описание полей файлов импорта';");
DB::query("CREATE TABLE {service_express_fields_category} (`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'идентификатор', `name` VARCHAR(250) NOT NULL DEFAULT '' COMMENT 'название', `module_name` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'название модуля', `type` ENUM('element', 'category', 'brand') NOT NULL DEFAULT 'element' COMMENT 'тип данных: element - элементы, category - категории', `delete_items` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'удалять не описанные в файле данные: 0 - нет, 1 - да', `site_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор страницы сайта из таблицы {site}', `cat_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор категории из таблицы {*module_name*_category}', `count_part` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'количество строк, выгружаемых за один проход скрипта', `sub_delimiter` VARCHAR(20) NOT NULL DEFAULT '' COMMENT 'разделитель данных внутри поля', `header` ENUM( '0', '1' ) NOT NULL DEFAULT '1' COMMENT 'первая строка - названия столбцов: 0 - нет, 1 - да', `sort` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'подрядковый номер для сортировки', `trash` ENUM( '0', '1' ) NOT NULL DEFAULT '0' COMMENT 'запись удалена в корзину: 0 - нет, 1 - да', PRIMARY KEY (id)) CHARSET=utf8 COMMENT 'Описание файлов импорта';");

DB::query("INSERT INTO {config} (`id`, `module_name`, `name`, `lang_id`, `value`, `site_id`) VALUES (NULL, 'service', 'express_preview_enable', '0', '1', '0');");
DB::query("INSERT INTO {config} (`id`, `module_name`, `name`, `lang_id`, `value`, `site_id`) VALUES (NULL, 'service', 'express_count_part', '0', '1000', '0');");

DB::query("ALTER TABLE {sessions} CHANGE `user_agent` `user_agent` TEXT COMMENT 'браузер пользователя';");
