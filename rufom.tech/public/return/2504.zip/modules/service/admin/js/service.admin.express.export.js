/**
 * Экспресс импорт/экспорт данных, JS-сценарий
 *
 * @package    DIAFAN.CMS
 * @author     diafan.ru
 * @version    6.0
 * @license    http://www.diafan.ru/license.html
 * @copyright  Copyright (c) 2003-2018 OOO «Диафан» (http://www.diafan.ru/)
 */

$(document).on('click', ".box_toggle i", function(event) {
  var unit_id = $(this).closest(".box_toggle").attr("unit_id");
  if(! unit_id)
  {
  	return false;
  }
  $("#"+unit_id).toggleClass("block_hide");
  /*event = event || window.event;
  var target = event.target || event.srcElement;
event.stopPropagation ? event.stopPropagation() : (event.cancelBubble=true);*/
});

$(document).on('change', 'select[name=modules]', function () {
 /*if(! $(this).attr('name'))
 {
   return false;
 }*/
 var self = $(this), element = this, form = $(this).closest('form');
 if(express_export)
 {
   express_export.info_reset();
 }
 diafan_ajax.init({
   data:{
     action: self.attr('name') + '_change',
     module: 'service',
     module_name: element.value
   },
   success: function(response) {
     if (response.result)
     {
       $.each(response.result, function (k, val) {
         $("#"+k).replaceWith(prepare(val));
       });
     }
     if (response.curLoc)
     {
       var curLoc = prepare(response.curLoc);
       $("#mode_express a.tabs__item.tabs__item_active").attr('href', curLoc);
       curLoc = curLoc.replace(window.location.protocol + "//" + window.location.host + "/", '');
       try {
       	history.pushState(null, null, "/" + curLoc);
       	return true;
       } catch(e) {}
       curLoc = curLoc.replace(/[\#|\?|\.](.*?)$/gi, '');
       var parts = curLoc.split(/\s*\/\s*/),
       	part = '';
       while (parts.length)
       {
       	part = parts.pop().replace(/[^\w]*/,'');
       	if(! part) continue;
       	window.chHashFlag = true;
       	location.hash = '#' + part;
       	break;
       }
       return false;
     }
   }
 });
 return false;
});


(function( $ ) {
  $.fn.getData = function() {
    var data = {}, self = this;
    if(! this || ! this.length)
    {
      return data;
    }
    $("input, select", this).each(function(index, element) {
  		var name = $(this).attr('name'),
  				type = $(this).attr('type'),
          tagName = $(element)[0].tagName,
          value = $(element).val();
      tagName = tagName.toUpperCase();
      if(! tagName || ! name)
      {
        return true;
      }
  		if(tagName == 'INPUT' && (! type || type == 'submit' || type == 'button'))
  		{
  			return true;
  		}
      if(tagName == 'INPUT' && type == 'checkbox')
      {
        if($(element).prop('checked'))
        {
          if($(element).val()) value = $(element).val();
          else value = $(element).prop('checked');
        }
        else value = '';
      }
      if(tagName == 'INPUT' && type == 'radio')
      {
        var radio = $("input[name='"+name+"']:checked", self);
        if (radio.length) value = radio.val();
        else value = '';
      }

      var levels = name.match( /(\[[A-Za-z0-9_]*\])/gi );
      if (levels)
      {
        var indx = name.search( /\[/ ),
            fld = name.substring(0, indx),
            field = fld;
        levels.forEach(function(item, index, array) {
          var level = item.replace( /\[([A-Za-z0-9_]*)\]/gi, '$1' );
          field = field + '[' + level + ']';
        });
        if (name == field && fld.length > 0)
        {
          if ( ! (fld in data) )
          {
            data[fld] = {};
          }
          var dt = data[fld];
          levels.forEach(function(item, index, array) {
            var level = item.replace( /\[([A-Za-z0-9_]*)\]/gi, '$1' );
            if ( ! (level in dt) )
            {
              if (! level.length)
              {
                var counter = 0;
                for (var key in dt) {
                  counter++;
                }
                level = String(counter);
              }
              dt[level] = {};
            }
            if (index < (array.length - 1)) dt = dt[level];
            else dt[level] = value;
          });
        }
        else data[name] = value;
      }
      else data[name] = value;
  	});
    return data; // return this;
  };
})( jQuery );

var express_export = {
  inArray: null,
  timeout: 100,
  timerId: 0,
  init: function() {
    if ([].indexOf) { express_export.inArray = function(array, value) { return array.indexOf(value); } }
    else { express_export.inArray = function(array, value) { for (var i = 0; i < array.length; i++) { if (array[i] === value) return i; } return -1; } }

    $(document).on('click', '#express_button', express_export.click);

    $(function() {
    	$(document).on('click', 'a.action', function () {
    		var self = $(this);
    		if (! self.attr("action"))
    		{
    			return true;
    		}
    		if (self.attr("confirm") && ! confirm(self.attr("confirm")))
    		{
    			return false;
    		}
    		return true;
    	});
    });
  },
  click: function() {
    var self = $(this);
    if(self.attr('disabled'))
    {
      return false;
    }
    self.attr('disabled', 'disabled');
    $("#express_fields_category_param input[name=delimiter]").attr("disabled", "disabled");
   	$("#express_fields_category_param input[name=enclosure]").attr("disabled", "disabled");
   	$("#express_fields_category_param select[name=encoding]").attr("disabled", "disabled");

    express_export.prepare();
    return false;
  },
  prepare: function() {
    var form = $('#form_express_export');
    if(! form.length)
    {
      return false;
    }
    var data = form.getData();
    data["action"] = 'export_data';
    data["module"] = 'service';
    diafan_ajax.init({
      data: data,
      success: function(response) {
        if (response.info_box) {
          express_export.info_reset(["info_box"]);
          $("#express_info_box").append(prepare(response.info_box));
          if (response.result == 'success')
          {
            var timerId = setTimeout(express_export.download('#file_export'), express_export.timeout);
          }
        }
        else express_export.info_reset(["info_box"]);
        if (response.result == 'continue') {
          express_export.timerId = setTimeout(express_export.prepare, express_export.timeout, true);
        }
        if (response.result == 'success') {
          $('#express_button').removeAttr('disabled');//.remove();
          $("#express_fields_category_param input[name=delimiter]").removeAttr('disabled');
         	$("#express_fields_category_param input[name=enclosure]").removeAttr('disabled');
         	$("#express_fields_category_param select[name=encoding]").removeAttr('disabled');
        }
      }
    });
    return false;
  },
  info_reset: function(params)
  {
    params = params || ["info_box", "request", "button"];
    if (express_export.inArray(params, "info_box") > -1)
    {
      $('#express_info_box').contents().remove();
    }
    if (express_export.inArray(params, "request") > -1)
    {
      $('#express_form_request').contents().remove();
    }
    if (express_export.inArray(params, "button") > -1)
    {
      if ($('#express_button').attr('default'))
      {
        $('#express_button').text($('#express_button').attr('default'));
      }
    }
  },
  download: function(tag_name) {
    tag_name = tag_name || '';
    var th = $(tag_name);
    if(! th.length)
    {
      return false;
    }
    var link = th[0];
    var linkEvent = null;
    if (document.createEvent) {
      linkEvent = document.createEvent('MouseEvents');
      linkEvent.initEvent('click', true, true);
      link.dispatchEvent(linkEvent);
    }
    else if (document.createEventObject) {
      linkEvent = document.createEventObject();
      link.fireEvent('onclick', linkEvent);
    }
  }
}
express_export.init();
