/**
 * Экспресс импорт/экспорт данных, JS-сценарий
 *
 * @package    DIAFAN.CMS
 * @author     diafan.ru
 * @version    6.0
 * @license    http://www.diafan.ru/license.html
 * @copyright  Copyright (c) 2003-2018 OOO «Диафан» (http://www.diafan.ru/)
 */

// === Загрузка файла импорта - start === //

$('#import_upload_file').on('submit', function(event) {
	event = event || window.event;
	event.preventDefault ? event.preventDefault() : (event.returnValue=false);
  var self = $(this);
	var file_link = $("input[name=file_link]", self).val() || false;
	if(file_link) {
		var data = self.serialize();
		if(data.length) data += '&';
		data += 'ajax=' + encodeURIComponent('1');
		diafan_ajax.init({
			data: data,
			before: function() {
				$('input:submit, button', self).attr("disabled", "disabled");
				$("input[name=file]", self).attr("disabled", "disabled");
				$("input[name=file_link]", self).attr("disabled", "disabled");
	      $("input[name=delimiter]", self).attr("disabled", "disabled");
	    	$("input[name=enclosure]", self).attr("disabled", "disabled");
	    	$("select[name=encoding]", self).attr("disabled", "disabled");

				diafan_download.init({
					url: file_link,
					self: $('#btn_upload_file'),
					before: function() { },
					success: function(response) {
						$("img.spinner_upload_file", self).removeClass("block_hide");
					},
			    error: function() { },
			    complete: function() { },
				});
			},
			success: function(response) {
				$('.progressbar', self).addClass("block_hide");
				$("img.spinner_upload_file", self).removeClass("block_hide");
			},
			error: function () {
				$('input:submit, button', self).removeAttr('disabled');
				$("input[name=file]", self).removeAttr('disabled');
				$("input[name=file_link]", self).removeAttr('disabled');
				$("input[name=delimiter]", self).removeAttr('disabled');
				$("input[name=enclosure]", self).removeAttr('disabled');
				$("select[name=encoding]", self).removeAttr('disabled');
				$("img.spinner_upload_file", self).addClass("block_hide");
			},
			done: function () {
				location.reload(true);
			}
		});
		return false;
	}

	if(! diafan_upload.is_support)
  {
    $("img.spinner_upload_file", self).removeClass("block_hide");
    return true;
  }
	diafan_upload.init({
    form: self,
    before: function() {
      $("input[name=file]", self).attr("disabled", "disabled");
			$("input[name=file_link]", self).attr("disabled", "disabled");
      $("input[name=delimiter]", self).attr("disabled", "disabled");
    	$("input[name=enclosure]", self).attr("disabled", "disabled");
    	$("select[name=encoding]", self).attr("disabled", "disabled");
    },
    after: function() {
      diafan_upload.button.attr("disabled", "disabled");
      $("img.spinner_upload_file", self).removeClass("block_hide");
    },
    error: function() {
      diafan_upload.button.removeAttr('disabled');
      $("input[name=file]", self).removeAttr('disabled');
			$("input[name=file_link]", self).removeAttr('disabled');
      $("input[name=delimiter]", self).removeAttr('disabled');
    	$("input[name=enclosure]", self).removeAttr('disabled');
    	$("select[name=encoding]", self).removeAttr('disabled');
			$("img.spinner_upload_file", self).addClass("block_hide");
    },
		success: function (response) {

		},
    complete: function () {
      location.reload(true);
    },
  });
  return false;
});

// === Загрузка файла импорта - end === //

// === Описание импорта в таблице - start === //

$(document).on('click', '.box .fields_express TR.row TD.col1 > .unit + i', function () {
  var table = $(this).closest("table"), owner = $(this).closest("tr"), th = owner.next("tr");
	if(th.length)
	{
		if(th.hasClass("block_hide"))
		{
      //table.find("tr.field").addClass("block_hide");
			//table.find("tr.row").removeClass("block_hover");
      table.find("tr.field").each(function(){
        if($(this).find('.errors').length) return true;
        $(this).addClass("block_hide");
        $(this).prev("tr.row").removeClass("block_hover");
      });

			th.removeClass("block_hide");
			owner.addClass("block_hover");
		}
		else
		{
			th.addClass("block_hide");
			owner.removeClass("block_hover");
		}
	}
});

$(document).on('change', 'select[name=express_fields_category_id]', function () {
	/*if(! $(this).attr('name'))
	{
		return false;
	}*/
	var self = $(this), element = this, form = $(this).closest('form');
	diafan_ajax.init({
		data:{
			action: self.attr('name') + '_change',
			module: 'service',
			module_name: $("input[name=module_name]", form).val(),
			id: element.value,
			count: $('table.fields_express tr.field td').length
		},
		success: function(response) {
			if (response.result)
			{
				$.each(response.result, function (k, val) {
					switch (k) {
						case "type":
						case "site_id":
						case "cat_id":
							if(val == 0 || val == '')
							{
								var th = $('#'+k+' select[name='+k+']');
								if(th.length)
								{
									$('option', th).removeAttr("selected");
									$('option:nth-child(1)', th).attr("selected", "selected");
								}
							}
							else $('#'+k+' select[name='+k+']').val(prepare(val));
							break;

						case "delete_items":
						case "header":
							val = (val == 0 ? false : true);
							$('#'+k+' input[name='+k+']').prop('checked', val);
							break;

						case "sub_delimiter":
            case "count_part":
							$('#'+k+' input[name='+k+']').val(val);
							break;

						default:
							break;
					}
				});
			}
			if (response.table)
			{
				var rows = response.table.rows || [],
						fields = response.table.fields || [];
				$('table.fields_express tr.row td.col1').each(function(index, element){
					if (index in rows) $(element).html(prepare(rows[index]));
					else $(element).html('');
				});
				$('table.fields_express tr.field td').each(function(index, element){
					if (index in rows) $(element).html(prepare(fields[index]));
					else $(element).html('');
				});
			}
			else
			{
				$('table.fields_express tr.row td.col1').each(function(){
					$(this).html('');
				});
				$('table.fields_express tr.field td').each(function(){
					$(this).html('');
				});
			}
			if (response.result || response.table)
			{
				check_type_cat();
				check_cell();
        express_import.info_reset();
			}
		}
	});
	return false;
});

$(document).on('change', "input[name='header']", check_cell);
function check_cell()
{
	var th = $('table.fields_express tr.row td:nth-child(2)'),
			checked = $('#header input[name="header"]').prop("checked") || false;
	if(! th.length)
	{
		return;
	}
	if(checked)
	{
		th.addClass('cell_disable');
	}
	else
	{
		th.removeClass('cell_disable');
	}
}
check_cell();

$(document).on('change', 'table.fields_express tr.field td input[name^="name["]', function() {
	var th = $(this).closest('tr.field').prev('tr.row').find('td.col1').eq(0);
	if(! th.length)
	{
		return;
	}
	var row_name = th.find('.row_name').eq(0);
	if(! row_name.length) th.prepend('<span class="row_name">' + $(this).val() + '</span> ');
	else row_name.html($(this).val());
});

$(document).on('change', 'table.fields_express tr.row td.col1 select[name^="type["]', function(){
  $(this).closest('tr.row').next('tr.field').find('.errors').remove();
});

$(document).on('change', 'table.fields_express tr.row td.col1 select[name^="type["]', function () {
	if( $(this).val() == 'empty')
	{
		return;
	}
  var owner = $(this).closest('tr.row');
  if(owner.length)
  {
    var th = owner.next("tr");
    if(th.length && th.hasClass("block_hide"))
    {
      $('TD.col1 > .unit + i', owner).trigger('click');
    }
  }
});

// === Описание импорта в таблице - end === //

// === Поле описания импорта в таблице - start === //

$(document).on('change', '#type select[name=type]', check_type_cat); // select[name=cat_id]
$(document).on('change', 'table.fields_express tr.row td.col1 select[name^="type["]', check_type);
$(document).on('change', 'table.fields_express tr.field td select[name^="param_id["]', check_param);
check_type_cat();

function check_type_cat()
{
	var type = false;
	if (this === window)
	{
		type = $('#type select[name=type] option:selected').attr('value'); // type_cat
	}
	else
	{ // $('#type select[name=type]').change();
		type = $(this).val();  // type_cat
	}

	if (! type)
	{
		return;
	}
	var th = $('table.fields_express').eq(0);
	if(! th.length)
	{
		return;
	}
	$('select[name^="type["] option', th).each(function(){
		if($(this).attr(type))
		{
			$(this).show();
		}
		else
		{
			$(this).hide();
		}
	});
	if(type == 'element')
	{
		$('select[name^="param_type["] option[value=article]', th).show();
	}
	else
	{
		$('select[name^="param_type["] option[value=article]', th).hide();
	}
	check_type();
}
function check_type()
{
	if (this === window)
	{ // полный перебор объектов
		var th = $('table.fields_express').eq(0);
		if(! th.length)
		{
			return;
		}
		$('tr.row td.col1 select[name^="type["]', th).each(function(){
			var fld = $(this).closest('tr.row').next('tr.field').find('td').eq(0);
			if(fld.length)
			{
				$('.params', fld).hide();
				$('.param_'+$(this).val(), fld).show();
			}
		});
	}
	else
	{ // обработка только инициирующего событие объекта
		// $('table.fields_express tr.row td.col1 select[name^="type["]').change();
		var fld = $(this).closest('tr.row').next('tr.field').find('td').eq(0);
		if(fld.length)
		{
			$('.params', fld).hide();
			$('.param_'+$(this).val(), fld).show();
		}
	}
	check_param();
}
function check_param()
{
	if (this === window)
	{ // полный перебор объектов
		var th = $('table.fields_express').eq(0);
		if(! th.length)
		{
			return;
		}
		$('tr.field td', th).each(function(){
			var fld = $(this);
			var row = fld.closest('tr.field').prev('tr.row').find('td.col1').eq(0);
			if (! row.length)
			{
				return;
			}
			if($('select[name^="type["]', row).val() == 'param' && ($('select[name^="param_id["] option:selected', fld).attr("type") == 'select' || $('select[name^="param_id["] option:selected', fld).attr("type") == 'multiple'))
			{
				$('[unit_id=param_select_type]', fld).show();
			}
			else
			{
				$('[unit_id=param_select_type]', fld).hide();
			}
			if($('select[name^="type["]', row).val() == 'param' && ($('select[name^="param_id["] option:selected', fld).attr("type") == 'images' || $('select[name^="param_id["] option:selected', fld).attr("type") == 'attachments') || $('select[name^="type["]', row).val() == 'images')
			{
				$('[unit_id=param_directory]', fld).show();
			}
			else
			{
				$('[unit_id=param_directory]', fld).hide();
			}
		});
	}
	else
	{ // обработка только инициирующего событие объекта
		// $('table.fields_express tr.field td select[name^="param_id["]').change();
		var fld = $(this).closest('td');
		if (! fld.length)
		{
			return;
		}
		var row = fld.closest('tr.field').prev('tr.row').find('td.col1').eq(0);
		if (! row.length)
		{
			return;
		}
		if($('select[name^="type["]', row).val() == 'param' && ($('select[name^="param_id["] option:selected', fld).attr("type") == 'select' || $('select[name^="param_id["] option:selected', fld).attr("type") == 'multiple'))
		{
			$('[unit_id=param_select_type]', fld).show();
		}
		else
		{
			$('[unit_id=param_select_type]', fld).hide();
		}
		if($('select[name^="type["]', row).val() == 'param' && ($('select[name^="param_id["] option:selected', fld).attr("type") == 'images' || $('select[name^="param_id["] option:selected', fld).attr("type") == 'attachments') || $('select[name^="type["]', row).val() == 'images')
		{
			$('[unit_id=param_directory]', fld).show();
		}
		else
		{
			$('[unit_id=param_directory]', fld).hide();
		}
	}
}

// === Поле описания импорта в таблице - end === //

// === Импорт - start === //

var express_import = {
  config: { data: {}, success: false },
  inArray: null,
  timeout: 100,
  timerId: 0,
  init: function() {
    if ([].indexOf) { express_import.inArray = function(array, value) { return array.indexOf(value); } }
    else { express_import.inArray = function(array, value) { for (var i = 0; i < array.length; i++) { if (array[i] === value) return i; } return -1; } }

    $(document).on('click', '#express_button', express_import.prepare);

    $(function() {
    	$(document).on('click', 'a.action', function () {
    		var self = $(this);
    		if (! self.attr("action"))
    		{
    			return true;
    		}
    		if (self.attr("confirm") && ! confirm(self.attr("confirm")))
    		{
    			return false;
    		}
    		return true;
    	});
    });
  },
  prepare: function() {
    var self = $(this);
    if(self.attr('disabled'))
    {
      return false;
    }
    var form = $('#form_express_import');
    if(! form.length)
    {
      return false;
    }
  	self.attr('disabled', 'disabled');

    express_import.config.data = form.getData();
    express_import.config.data["category"] = $('#form_express_import_category').getData();
    express_import.config.data["request"] = $('#express_form_request').getData();
  	express_import.config.success = function(response) {
      if(response.errors) { // TO_DO: admin.edit.js - response.errors
        express_import.errors_reset();
        var focus = false;
  			var other = false;
  			$.each(response.errors, function (k, val) {
          if (k) {
            if(typeof(val) == 'object')
            {
              $.each(val, function (key, value) {
                var th = form.find('[unit_id="'+k+'"]').eq(key);
                if (th.length)
                {
                  var field = th.after('<div class="errors error">' + prepare(value) + '</div>')
                    .closest('tr.field ').removeClass('block_hide');
                  if(! focus && field.length)
                  {
                    focus = true;
                    $('html, body').scrollTop((field||$()).offset().top - (field.prev('tr.row')||$()).outerHeight(true) - 40);
                  }
                }
                else $(".content").after('<div class="errors error">' + prepare(value) + '</div>');
              });
            }
            else
            {
              if(! other)
    					{
    						if($("#"+k).parents('.content__right_supp').length && parseInt($('.content__right_supp').css('right')) < 0)
    						{
    							$('.btn_supp').click();
    							other = true;
    						}
    					}
    					$("#"+k).after('<div class="errors error">' + prepare(val) + '</div>');
    					if(! focus)
    					{
    						$("#"+k).find("input, submit, textarea").first().focus();
    						focus = true;
    					}
            }
          }
          else {
            if(typeof(val) == 'object')
            {
              $.each(val, function (key, value) {
                $(".content").after('<div class="errors error">' + prepare(value) + '</div>');
              });
            }
            else
            {
              $(".content").after('<div class="errors error">' + prepare(val) + '</div>');
            }
          }
  			});
  		}
      else express_import.errors_reset();
      if (response.request) {
        express_import.info_reset(["request"]);
        $("#express_form_request").append(prepare(response.request));
      }
      else express_import.info_reset(["request"]);
      if (response.button) {
        $('#express_button').text(prepare(response.button));
      }
      else express_import.info_reset(["button"]);
  		if (response.info_box) {
        express_import.info_reset(["info_box"]);
        $("#express_info_box").append(prepare(response.info_box));
  		}
      else express_import.info_reset(["info_box"]);
      if (response.redirect) {
  			window.location = prepare(response.redirect);
  		}
      if (response.category) {
        $("#express_fields_category_id").replaceWith(prepare(response.category));
  		}
      if (response.result == 'defer_files') {
        var timerId = setTimeout(express_import.load_defer_files, express_import.timeout);
  		}
      if (response.result == 'import_files') {
        var timerId = setTimeout(express_import.import_files, express_import.timeout);
      }
      if (response.result == 'success') {
  			self.removeAttr('disabled');
  		}
  	}
  	diafan_ajax.init(express_import.config);
  	return false;
  },
  errors_reset: function()
  {
    $('table.fields_express').find('.errors').remove();
  },
  info_reset: function(params)
  {
    params = params || ["info_box", "request", "button"];
    if (express_import.inArray(params, "info_box") > -1)
    {
      $('#express_info_box').contents().remove();
    }
    if (express_import.inArray(params, "request") > -1)
    {
      $('#express_form_request').contents().remove();
    }
    if (express_import.inArray(params, "button") > -1)
    {
      if ($('#express_button').attr('default'))
      {
        $('#express_button').text($('#express_button').attr('default'));
      }
    }
  },
  load_defer_files: function() {
    $('#express_button').attr('disabled', 'disabled');
    var data = $("#csv_param").getData();
    data["action"] = 'load_defer_files';
    data["module"] = 'service';
    diafan_ajax.init({
      data: data,
      success: function(response) {
        if (response.info_box) {
          express_import.info_reset(["info_box"]);
          $("#express_info_box").append(prepare(response.info_box));
    		}
        else express_import.info_reset(["info_box"]);
        if (response.result == 'continue') {
          express_import.timerId = setTimeout(express_import.load_defer_files, express_import.timeout);
        }
        if (response.result == 'import_files') {
          var timerId = setTimeout(express_import.import_files, express_import.timeout);
    		}
        if (response.result == 'success') {
          $('#express_button').removeAttr('disabled');
        }
        if (response.redirect) {
    			window.location = prepare(response.redirect);
    		}
      }
    });
    return false;
  },
  import_files: function() {
    $('#express_button').attr('disabled', 'disabled');
    diafan_ajax.init({
      data:{
        action: 'import_files',
        module: 'service',
        cat_id: $('select[name=express_fields_category_id]', $('#form_express_import_category')).val()
      },
      success: function(response) {
        if (response.info_box) {
          express_import.info_reset(["info_box"]);
          $("#express_info_box").append(prepare(response.info_box));
          if (response.result == 'success')
          {
            var timerId = setTimeout(express_import.download('#file_errors_log'), express_import.timeout);
          }
    		}
        else express_import.info_reset(["info_box"]);
        if (response.result == 'continue') {
          express_import.timerId = setTimeout(express_import.import_files, express_import.timeout);
        }
        if (response.result == 'success') {
          $('html, body').scrollTop(($('#import_init')||$()).offset().top - ($('#import_description')||$()).outerHeight(true) - 40);
          $('#import_description').remove();
          $('#express_button').removeAttr('disabled').remove();
        }
      }
    });
    return false;
  },
  download: function(tag_name) {
    tag_name = tag_name || '';
    var th = $(tag_name);
    if(! th.length)
    {
      return false;
    }
    var link = th[0];
    var linkEvent = null;
    if (document.createEvent) {
      linkEvent = document.createEvent('MouseEvents');
      linkEvent.initEvent('click', true, true);
      link.dispatchEvent(linkEvent);
    }
    else if (document.createEventObject) {
      linkEvent = document.createEventObject();
      link.fireEvent('onclick', linkEvent);
    }
  }
};
express_import.init();

// === Импорт - end === //

// === Операции с запясями после импорта - start === //

$(document).on('click', '.import_button', function(){
 	var value = $(this).attr('rel');
 	$('input[name="import_action"]').val(value);
});

// === Операции с запясями после импорта - end === //

// === Общее - start === //

$(document).on('click', '.box_toggle i', function(event) {
	var unit_id = $(this).closest(".box_toggle").attr("unit_id");
	if(! unit_id)
	{
		return false;
	}
	$("#"+unit_id).toggleClass("block_hide");
});

var diafan_upload = {
  data: false,
  url: false,
  before: false,
  after: false,
  success: false,
  error: false,
  complete: false,
  form: {},
  button: {},
  progressBar: {},
  progressLine: {},
  has_progressBar: false,
  has_progressLine: false,
  onSubmitBefore: function(form){},
  onSubmitAfter: function(form){},
  onSubmitError: function(form, errorThrown){},
  is_support: !! window.FormData,

	init: function(config) {
    if(! this.is_support)
    {
      return true;
    }
    if(config.form)
    {
      this.form = config.form;
      if(! this.form.length) return true;
    }
    if(config.data)
    {
      this.data = config.data;
    }
    else
    {
      this.data = new FormData(this.form.get(0));
      var ajax = false;
      for (var pair of this.data.entries()) {
        if(pair[0] != 'ajax' || ! pair[1]) continue;
        ajax = true;
      }
      if (! ajax) this.data.append('ajax', '1');
    }
    if(config.url) this.url = config.url;
    else
    {
      if(this.form.attr('action')) this.url = this.form.attr('action');
      else this.url = window.location.href;
    }
    if(config.before) this.before = config.before;
    else this.before = (function(form){});
    if(config.success) this.success = config.success;
    else this.success = (function(response, form){});
    if(config.after) this.after = config.after;
    else this.after = (function(form){});
    if(config.error) this.error = config.error;
    else this.error = (function(form){});
    if(config.complete) this.complete = config.complete;
    else this.complete = (function(form){});
    this.data.check_hash_user = $('.check_hash_user').text();

    this.button = $('input:submit, button', this.form).eq(0);
    if(! this.button.length) return true;
    this.progressBar = $('.progressbar', this.form).eq(0);
    if(! this.progressBar.length)
    {
      this.has_progressBar = false;
      this.button.after('<div class="progressbar block_hide"></div>');
      this.progressBar = $('.progressbar', this.form).eq(0);
    }
    else this.has_progressBar = true;
    this.progressLine = $('.line', this.progressBar).eq(0);
    if(! this.progressLine.length)
    {
      this.has_progressLine = false;
      this.progressBar = this.progressBar.append('<div class="line"></div>');
      this.progressLine = $('.line', this.progressBar).eq(0);
    }
    else this.has_progressLine = true;

    if(this.before(this.form) === false)
    {
      return false;
    }
    $(this.form).trigger('ajax_submit.before', [ this.form ]);
    this.onSubmitBefore(this.form);

    this.button.attr('disabled', 'disabled');
    this.progressLine.css("width", 0+"%");
    this.progressBar.removeClass('block_hide');
    return $.ajax({
      url: this.url,
      type: this.form.attr('method') || 'POST',
      contentType: false,
      processData: false,
      data: this.data,
      dataType: 'json',
      xhr: function(){
        var xhr = $.ajaxSettings.xhr(); // получаем объект XMLHttpRequest
        xhr.upload.addEventListener('progress', function(evt){ // добавляем обработчик события progress (onprogress)
          if(evt.lengthComputable) { // если известно количество байт
            // высчитываем процент загруженного
            var percentComplete = Math.ceil(evt.loaded / evt.total * 100);
            // устанавливаем значение в progress
            diafan_upload.progressLine.css("width", percentComplete+"%");
          }
        }, false);
        return xhr;
      },
      success: function(response, statusText, xhr, form) {
        diafan_upload.button.removeAttr('disabled');
        if(diafan_upload.after(this.form) === false)
        {
          return false;
        }
        $(document).trigger('ajax_submit.after', [ form ]);
        if (response.redirect) {
          window.location = prepare(response.redirect);
        }
        if (response.hash) {
          $('input[name=check_hash_user]').val(response.hash);
          $('.check_hash_user').text(response.hash);
        }
        diafan_upload.success(response, form);
      },
      error: function(xhr, statusText, errorThrown){
				diafan_upload.progressBar.addClass('block_hide');
        diafan_upload.progressLine.css("width", 0+"%");
        if(! diafan_upload.has_progressLine) diafan_upload.progressLine.remove();
        if(! diafan_upload.has_progressBar) diafan_upload.progressBar.remove();
        if(diafan_upload.error(diafan_upload.form) === false)
        {
          return false;
        }
        $(document).trigger('ajax_submit.error', [ diafan_upload.form, errorThrown ]);
        // TO_DO: errorThrown = (statusText === 'timeout' ? 'timeout' : 'aborted');
        diafan_upload.onSubmitError(diafan_upload.form, errorThrown);
      },
      complete: function(xhr, statusText) {
        diafan_upload.progressBar.addClass('block_hide');
        diafan_upload.progressLine.css("width", 0+"%");
        if(! diafan_upload.has_progressLine) diafan_upload.progressLine.remove();
        if(! diafan_upload.has_progressBar) diafan_upload.progressBar.remove();
        if(diafan_upload.complete(diafan_upload.form) === false)
        {
          return false;
        }
      }
    });
    return false;
  }
};

var diafan_download = {
  url: false,
  self: {},
	before: false,
	success: false,
  error: false,
  complete: false,
  progressBar: {},
  progressLine: {},
  has_progressBar: false,
  has_progressLine: false,

	init: function(config) {
    if(config.self)
    {
      this.self = config.self;
      if(! this.self.length) return true;
    }
    if(config.url) this.url = config.url;
    else
    {
      return false;
    }
		if(config.before) this.before = config.before;
    else this.before = (function(){});
		if(config.success) this.success = config.success;
    else this.success = (function(response){});
    if(config.error) this.error = config.error;
    else this.error = (function(){});
    if(config.complete) this.complete = config.complete;
    else this.complete = (function(){});

    this.progressBar = this.self.next('.progressbar').eq(0);
    if(! this.progressBar.length)
    {
      this.has_progressBar = false;
      this.self.after('<div class="progressbar block_hide"></div>');
      this.progressBar = this.self.next('.progressbar').eq(0);
    }
    else this.has_progressBar = true;
    this.progressLine = $('.line', this.progressBar).eq(0);
    if(! this.progressLine.length)
    {
      this.has_progressLine = false;
      this.progressBar = this.progressBar.append('<div class="line"></div>');
      this.progressLine = $('.line', this.progressBar).eq(0);
    }
    else this.has_progressLine = true;

		if(this.before() === false)
    {
      return false;
    }

    this.progressLine.css("width", 0+"%");
    this.progressBar.removeClass('block_hide');
    return $.ajax({
      url: this.url,
      type: 'GET',// 'POST',
      contentType: false,
      processData: false,
      xhr: function(){
        var xhr = $.ajaxSettings.xhr(); // получаем объект XMLHttpRequest
        xhr.addEventListener('progress', function(evt){ // добавляем обработчик события progress (onprogress)
          if(evt.lengthComputable) { // если известно количество байт
            // высчитываем процент загруженного
            var percentComplete = Math.ceil(evt.loaded / evt.total * 100);
            // устанавливаем значение в progress
            diafan_download.progressLine.css("width", percentComplete+"%");
          }
        }, false);
        return xhr;
      },
      success: function(response) {
				diafan_download.success(response);
      },
      error: function(xhr, statusText, errorThrown){
        diafan_download.progressBar.addClass('block_hide');
        diafan_download.progressLine.css("width", 0+"%");
        if(! diafan_download.has_progressLine) diafan_download.progressLine.remove();
        if(! diafan_download.has_progressBar) diafan_download.progressBar.remove();
        if(diafan_download.error() === false)
        {
          return false;
        }
      },
      complete: function(xhr, statusText) {
        diafan_download.progressBar.addClass('block_hide');
        diafan_download.progressLine.css("width", 0+"%");
        if(! diafan_download.has_progressLine) diafan_download.progressLine.remove();
        if(! diafan_download.has_progressBar) diafan_download.progressBar.remove();
        if(diafan_download.complete() === false)
        {
          return false;
        }
      }
    });
    return false;
  }
};

(function( $ ) {
  $.fn.getData = function() {
    var data = {}, self = this;
    if(! this || ! this.length)
    {
      return data;
    }
    // var array = this.serializeArray();
    $("input, select", this).each(function(index, element) {
  		var name = $(this).attr('name'),
  				type = $(this).attr('type'),
          tagName = $(element)[0].tagName,
          value = $(element).val();
      tagName = tagName.toUpperCase();
      if(! tagName || ! name)
      {
        return true;
      }
  		if(tagName == 'INPUT' && (! type || type == 'submit' || type == 'button'))
  		{
  			return true;
  		}
      if(tagName == 'INPUT' && type == 'checkbox')
      {
        if($(element).prop('checked'))
        {
          if($(element).val()) value = $(element).val();
          else value = $(element).prop('checked');
        }
        else value = '';
      }
      if(tagName == 'INPUT' && type == 'radio')
      {
        var radio = $("input[name='"+name+"']:checked", self);
        if (radio.length) value = radio.val();
        else value = '';
      }

      var levels = name.match( /(\[[A-Za-z0-9_]*\])/gi );
      if (levels)
      {
        var indx = name.search( /\[/ ),
            fld = name.substring(0, indx),
            field = fld;
        levels.forEach(function(item, index, array) {
          var level = item.replace( /\[([A-Za-z0-9_]*)\]/gi, '$1' );
          field = field + '[' + level + ']';
        });
        if (name == field && fld.length > 0)
        {
          if ( ! (fld in data) )
          {
            data[fld] = {};
          }
          var dt = data[fld];
          levels.forEach(function(item, index, array) {
            var level = item.replace( /\[([A-Za-z0-9_]*)\]/gi, '$1' );
            if ( ! (level in dt) )
            {
              if (! level.length)
              {
                var counter = 0;
                for (var key in dt) {
                  counter++;
                }
                level = String(counter);
              }
              dt[level] = {};
            }
            if (index < (array.length - 1)) dt = dt[level];
            else dt[level] = value;
          });
        }
        else data[name] = value;
      }
      else data[name] = value;
  	});
    return data; // return this;
  };
})( jQuery );

// === Общее - end === //
