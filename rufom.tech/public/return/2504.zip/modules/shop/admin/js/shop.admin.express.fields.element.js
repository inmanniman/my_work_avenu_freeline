/**
 * Экспресс импорт/экспорт данных, JS-сценарий
 *
 * @package    DIAFAN.CMS
 * @author     diafan.ru
 * @version    6.0
 * @license    http://www.diafan.ru/license.html
 * @copyright  Copyright (c) 2003-2018 OOO «Диафан» (http://www.diafan.ru/)
 */

$(document).on('click', '.box_refresh i', function(event) {
  var self = $(this),
      that = self.closest('.box_refresh');
  if (self.attr('disabled'))
  {
    return;
  }
  self.attr('disabled', 'disabled');
  diafan_ajax.init({
    data: {
      action: 'table_params_refresh',
      module: 'shop',
      id: that.attr("field_id") || 0
    },
    success: function(response) {
      if(response.result) {
        that.replaceWith(prepare(response.result));
      }
    }
  });
  return false;
});
