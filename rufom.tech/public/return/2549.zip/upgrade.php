<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("CREATE TABLE {executable} (
`master_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'главный идентификатор в формате UNIXTIME',
`slave_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'вторичный идентификатор в интервале master_id',
`id` VARCHAR(21) NOT NULL DEFAULT '' COMMENT 'объединенный идентификатор',
`created` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'дата создания',
`timeedit` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'время последнего изменения в формате UNIXTIME',
`module_name` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'название модуля',
`method` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'название метода',
`params` TEXT COMMENT 'серилизованные параметры инициализации',
`text` TEXT COMMENT 'описание процесса',
`is_admin` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'статус: 0 - общая часть сайта, 1 - административная часть сайта',
`rewrite` VARCHAR(250) NOT NULL DEFAULT '' COMMENT 'псевдоссылка',
`iteration` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'порядковый номер итерации',
`max_iteration` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'максимальный номер итерации',
`init_params` TEXT COMMENT 'серилизованные параметры первичной инициализации',
`init_backtrace` TEXT COMMENT 'стек вызовов функций инициализации',
`result` TEXT COMMENT 'результат исполнения процесса',
`break` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'статус: 0 - процесс разрешён, 1 - процесс прерван',
`status` ENUM('0', '1', '2', '3') NOT NULL DEFAULT '0' COMMENT 'статус: 0 - ожидает инициализации, 1 - процесс выполнения, 2 - процесс завершен, 3 - ошибка во время выполнения',
`forced` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'принудительное исполнение: 0 - нет, 1 - да',
`prior` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'приоритет исполнения: 0 - без приоритета, 1 - приоритетно',
`trash` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'считать запись мусором по завершению процесса: 0 - нет, 1 - да',
PRIMARY KEY (`master_id`, `slave_id`)
) CHARSET=utf8 COMMENT 'Реестр фоновых процессов'");

$admin_row_id = DB::query(
	"INSERT INTO {admin} (`parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`, `icon_name`)
	VALUES (0, 2, '5', 'Фоновые процессы', 'executable', '1', '0', '', 35, '', 'tasks')"
);
DB::query(
	"INSERT INTO {admin} (`parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`, `icon_name`)
	VALUES (%d, 0, '5', 'Реестр фоновых процессов', 'executable', '1', '0', '', 1, '', 'tasks')", $admin_row_id
);
DB::query(
	"INSERT INTO {admin} (`parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`, `icon_name`)
	VALUES (%d, 0, '5', 'Настройки', 'executable/config', '0', '0', '', 2, '', 'tasks');", $admin_row_id
);

DB::query(
	"INSERT INTO {modules} (`name`, `module_name`, `site`, `site_page`, `admin`, `title`)
	VALUES ('executable', 'core', '0', '0', '1', 'Фоновые процессы')"
);

DB::query("CREATE TABLE {crontab} (
`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'идентификатор',
`name` VARCHAR(100) NOT NULL DEFAULT '' COMMENT 'название задачи',
`text` TEXT COMMENT 'описание задачи',
`datetime` VARCHAR(21) NOT NULL DEFAULT '' COMMENT 'время выполнения в формате CRONTAB',
`module_name` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'название модуля',
`method` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'название метода',
`params` VARCHAR(250) NOT NULL DEFAULT '' COMMENT 'параметры инициализации в формате JSON',
`act` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'активное задание: 0 - нет, 1 - да',
`sort` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'подрядковый номер для сортировки',
`timeedit` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'время последнего изменения в формате UNIXTIME',
`timeinit` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'время последней инициализации задачи в формате UNIXTIME',
`result` TEXT COMMENT 'результат исполнения процесса',
`errors` TEXT COMMENT 'ошибки при исполнении процесса',
`content` TEXT COMMENT 'контент по результатам исполнения процесса',
`trash` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'запись удалена в корзину: 0 - нет, 1 - да',
PRIMARY KEY (id)
) CHARSET=utf8 COMMENT 'Расписание задач'");

$admin_row_id = DB::query(
	"INSERT INTO {admin} (`parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`, `icon_name`)
	VALUES (0, 2, '5', 'Расписание задач', 'crontab', '1', '0', '', 36, '', 'calendar-o')"
);
DB::query(
	"INSERT INTO {admin} (`parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`, `icon_name`)
	VALUES (%d, 0, '5', 'Список задач', 'crontab', '1', '0', '', 1, '', 'calendar-o')", $admin_row_id
);
DB::query(
	"INSERT INTO {admin} (`parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`, `icon_name`)
	VALUES (%d, 0, '5', 'Настройки', 'crontab/config', '0', '0', '', 2, '', 'calendar-o');", $admin_row_id
);

DB::query(
	"INSERT INTO {modules} (`name`, `module_name`, `site`, `site_page`, `admin`, `title`)
	VALUES ('crontab', 'core', '0', '0', '1', 'Расписание задач')"
);

// TO_DO: если был скачен старый (битый) пакета 2548, то не выставлялась текущая точка для такого пакета.
// Причина: сбивалось значение переменной $id, так как она использовалась в битом пакете.
try
{
	$upd_trash_id = 2548;
	if(file_exists(ABSOLUTE_PATH.'return/'.$upd_trash_id.'.zip') && File::hash_file('return/'.$upd_trash_id.'.zip') == 'f334d3aedac20418f3708fcc2ff284b7')
	{
		// Удаляем битый пакет 2548 и восстанавливаем его вновь.
		if($upd_trash_hash = DB::query_result("SELECT hash FROM {update_return} WHERE id=%d LIMIT 1", $upd_trash_id))
		{
			File::delete_file('return/'.$upd_trash_id.'.zip');
			File::copy_file('http'.(IS_HTTPS ? "s" : '').'://user.diafan.ru/file/update/'.$upd_trash_id.'/'.$upd_trash_hash, 'return/'.$upd_trash_id.'.zip');
		}
	}
}
catch(Exception $e) {}


// Для DIAFAN.CMS 6.0.11.10
