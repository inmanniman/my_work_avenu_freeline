<?php
if (! defined('DIAFAN'))
{
	exit;
}


DB::query("DROP TABLE {executable}");

if($admin_row_id = DB::query_result("SELECT id FROM {admin} WHERE `rewrite`='%h' LIMIT 1", 'executable'))
{
	DB::query("DELETE FROM {admin} WHERE id=%d", $admin_row_id);
	DB::query("DELETE FROM {admin} WHERE parent_id=%d", $admin_row_id);
}

DB::query("DELETE FROM {modules} WHERE name='%h'", 'executable');

DB::query("DROP TABLE {crontab}");

if($admin_row_id = DB::query_result("SELECT id FROM {admin} WHERE `rewrite`='%h' LIMIT 1", 'crontab'))
{
	DB::query("DELETE FROM {admin} WHERE id=%d", $admin_row_id);
	DB::query("DELETE FROM {admin} WHERE parent_id=%d", $admin_row_id);
}

DB::query("DELETE FROM {modules} WHERE name='%h'", 'crontab');

// Для DIAFAN.CMS 6.0.11.10
