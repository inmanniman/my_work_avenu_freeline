<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("UPDATE {modules} SET admin='1' WHERE name='cart'");
DB::query("UPDATE {admin} SET rewrite='cart' WHERE rewrite='shop/cart'");

DB::query("ALTER TABLE {shop_cart} ADD `summ` DOUBLE NOT NULL DEFAULT '0' COMMENT 'сумма заказа', ADD `count_goods` DOUBLE NOT NULL DEFAULT '0' COMMENT 'количество товарных позиций'");

DB::query("ALTER TABLE {shop_cart} ADD `delivery_id` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0', ADD `additional_cost` TEXT, ADD `orders` TEXT;");

$rows = DB::query_fetch_all("SELECT * FROM {shop_cart_goods} WHERE param<>''");
foreach($rows as $row)
{
	$p = unserialize($row["param"]);
	sort($p);
	DB::query("UPDATE {shop_cart_goods} SET param='%s' WHERE id=%d", implode(',', $p), $row["id"]);
}

DB::query("ALTER TABLE {shop_order} ADD `coupon` VARCHAR( 10 ) NOT NULL DEFAULT '';");

DB::query("CREATE TABLE {shop_cart_log_mail} (
`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'идентификатор',
`created` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'дата отправления',
`cart_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор корзины из таблицы {cart_id}',
`order_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор заказа из таблицы {shop_order}',
`trash` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'запись удалена в корзину: 0 - нет, 1 - да',
PRIMARY KEY (id),KEY cart_id (`cart_id`)
) CHARSET=utf8 COMMENT 'Лог отправлений писем'");

if(Custom::path('modules/cart/views/cart.view.table.php') != 'modules/cart/views/cart.view.table.php' && Custom::path('modules/cart/js/cart.form.js') == 'modules/cart/js/cart.form.js')
{
	File::copy_file(ABSOLUTE_PATH.'modules/cart/js/cart.form.js', str_replace('modules/cart/views/cart.view.table.php', '', Custom::path('modules/cart/views/cart.view.table.php')).'modules/cart/js/cart.form.js');

DB::query("ALTER TABLE {admin} CHANGE `group_id` `group_id` ENUM('1','2','3','4','5','6','7') NOT NULL DEFAULT '1' COMMENT 'группа';");
}
