<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("UPDATE {admin} SET rewrite='shop/cart' WHERE rewrite='cart'");
DB::query("ALTER TABLE {shop_cart} DROP `summ`, DROP `count_goods`");

DB::query("ALTER TABLE {shop_cart} DROP `delivery_id`, DROP `additional_cost`, DROP `orders`;");

$rows = DB::query_fetch_all("SELECT * FROM {shop_cart_goods} WHERE param<>''");
foreach($rows as $row)
{
	if(preg_match('/[^0-9\,]+/', $row["param"]))
		continue;

	$p = DB::query_fetch_key_value("SELECT id, param_id FROM {shop_param_select} WHERE id IN(%s)", $row["param"], "param_id", "id");	
	DB::query("UPDATE {shop_cart_goods} SET param='%s' WHERE id=%d", serialize($p), $row["id"]);
}
DB::query("ALTER TABLE {shop_order} DROP `coupon`;");

DB::query("DROP TABLE {shop_cart_log_mail}");