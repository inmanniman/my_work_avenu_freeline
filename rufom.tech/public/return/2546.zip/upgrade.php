<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("ALTER TABLE {postman} CHANGE `id` `id` VARCHAR(21) NOT NULL DEFAULT '' COMMENT 'объединенный идентификатор'");
DB::query("ALTER TABLE {visitors_session} CHANGE `id` `id` VARCHAR(21) NOT NULL DEFAULT '' COMMENT 'объединенный идентификатор'");
DB::query("ALTER TABLE {visitors_url} CHANGE `id` `id` VARCHAR(21) NOT NULL DEFAULT '' COMMENT 'объединенный идентификатор'");
DB::query("ALTER TABLE {visitors_url} CHANGE `visitors_session_id` `visitors_session_id` VARCHAR(21) NOT NULL DEFAULT '' COMMENT 'идентификатор посетителей из таблицы {visitors_session}'");
DB::query("ALTER TABLE {visitors_stat_traffic_source} CHANGE `id` `id` VARCHAR(21) NOT NULL DEFAULT '' COMMENT 'объединенный идентификатор'");
DB::query("ALTER TABLE {visitors_stat_traffic_pages} CHANGE `id` `id` VARCHAR(21) NOT NULL DEFAULT '' COMMENT 'объединенный идентификатор'");
DB::query("ALTER TABLE {visitors_stat_traffic_names_search_bot} CHANGE `id` `id` VARCHAR(21) NOT NULL DEFAULT '' COMMENT 'объединенный идентификатор'");
DB::query("ALTER TABLE {shop_cashregister} CHANGE `id` `id` VARCHAR(21) NOT NULL DEFAULT '' COMMENT 'объединенный идентификатор'");

// Для DIAFAN.CMS 6.0.11.7
