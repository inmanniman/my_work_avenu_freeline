<?php
if (! defined('DIAFAN'))
{
	exit;
}


DB::query("ALTER TABLE {postman} CHANGE `id` `id` TEXT COMMENT 'объединенный идентификатор'");
DB::query("ALTER TABLE {visitors_session} CHANGE `id` `id` TEXT COMMENT 'объединенный идентификатор'");
DB::query("ALTER TABLE {visitors_url} CHANGE `id` `id` TEXT COMMENT 'объединенный идентификатор'");
DB::query("ALTER TABLE {visitors_url} CHANGE `visitors_session_id` `visitors_session_id` TEXT COMMENT 'идентификатор посетителей из таблицы {visitors_session}'
");
DB::query("ALTER TABLE {visitors_stat_traffic_source} CHANGE `id` `id` TEXT COMMENT 'объединенный идентификатор'");
DB::query("ALTER TABLE {visitors_stat_traffic_pages} CHANGE `id` `id` TEXT COMMENT 'объединенный идентификатор'");
DB::query("ALTER TABLE {visitors_stat_traffic_names_search_bot} CHANGE `id` `id` TEXT COMMENT 'объединенный идентификатор'");
DB::query("ALTER TABLE {shop_cashregister} CHANGE `id` `id` TEXT COMMENT 'объединенный идентификатор'");

// Для DIAFAN.CMS 6.0.11.7
