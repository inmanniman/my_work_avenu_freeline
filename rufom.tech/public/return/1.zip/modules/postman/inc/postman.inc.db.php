<?php
/**
 * Подключение модуля «Уведомления» для работы с базой данных
 *
 * @package    DIAFAN.CMS
 * @author     diafan.ru
 * @version    6.0
 * @license    http://www.diafan.ru/license.html
 * @copyright  Copyright (c) 2003-2018 OOO «Диафан» (http://www.diafan.ru/)
 */

if ( ! defined('DIAFAN'))
{
	$path = __FILE__;
	while(! file_exists($path.'/includes/404.php'))
	{
		$parent = dirname($path);
		if($parent == $path) exit;
		$path = $parent;
	}
	include $path.'/includes/404.php';
}

/**
 * Postman_inc_db
 */
class Postman_inc_db extends Diafan
{
	const TABLE_NAME = 'postman';
	const SEPARATOR = '-';

	/**
	 * Получает первичные ключи таблицы
	 *
	 * @return array
	 */
	private function primary_keys()
	{
		if(! isset($this->cache["PRIMARY_KEYS"]) || ! isset($this->cache["PRIMARY_KEYS"][self::TABLE_NAME]))
		{
			$this->cache["PRIMARY_KEYS"][self::TABLE_NAME] = DB::query_fetch_value("SHOW KEYS FROM {".self::TABLE_NAME."} WHERE Key_name = 'PRIMARY'", "Column_name");
		}
		return $this->cache["PRIMARY_KEYS"][self::TABLE_NAME];
	}

	/**
	 * Валидация идентификатора уведомления
	 *
	 * @param array $id идентификатор уведомления
	 * @param boolean $isset проверка наличия записи в тавблице уведомлений
	 * @return boolean
	 */
	private function valid_id($id, $isset = false)
	{
		if(! is_array($id) || ! $primary_keys = $this->primary_keys())
		{
			return false;
		}
		$where = ' WHERE 1=1'; $keys = array();
		foreach($primary_keys as $primary_key)
		{
			if(! empty($primary_key) && ! empty($id[$primary_key]))
			{
				$where .= ' AND '.$primary_key.'=%d';
				$keys[$primary_key] = $id[$primary_key];
				continue;
			}
			return false;
		}
		if($isset)
		{
			if(! $row = DB::query_fetch_array("SELECT * FROM {".self::TABLE_NAME."}".$where." LIMIT 1", $keys))
			{
				return false;
			}
		}
		return true;
	}

	/**
	 * Преобразует идентификатор уведомления
	 *
	 * @param mixed(array|string) $id идентификатор уведомления
	 * @return mixed(string|array)
	 */
	public function converter_id($id)
	{
		if(is_array($id))
		{
			if(! $this->valid_id($id))
			return false;

			$primary_keys = $this->primary_keys();
			foreach($primary_keys as $primary_key)
			{
				if(! empty($primary_key) && ! empty($id[$primary_key]))
				{
					$keys[$primary_key] = $id[$primary_key];
					continue;
				}
				return false;
			}
			return implode(self::SEPARATOR, $keys);
		}
		elseif(is_string($id))
		{
			$id = explode(self::SEPARATOR, $id);
			$primary_keys = $this->primary_keys();
			if(count($id) != count($primary_keys))
			return false;

			foreach($primary_keys as $primary_key)
			{
				$id_value = array_shift($id);
				if(! empty($primary_key) && ! empty($id_value))
				{
					$keys[$primary_key] = $id_value;
					continue;
				}
				return false;
			}

			if(! $this->valid_id($keys))
			return false;

			return $keys;
		}

		return false;
	}

	/**
	 * Добавляет уведомление
	 *
	 * @param mixed(string|array) $recipient получатель/получатели
	 * @param string $subject тема письма
	 * @param string $body содержание письма
	 * @param string $from адрес отправителя
	 * @param string $type тип уведомления: 'mail' - письмо,  'sms' - короткое сообщение
	 * @param boolean $auto метод отправки уведомления: false - ручной, true - автоматический
	 */
	public function add($recipient, $subject, $body, $from = '', $type = 'mail', $auto = true)
	{
		if($type != 'mail' && $type != 'sms')
		{
			return false;
		}
		$auto = $auto ? 1 : 0;
		$recipient = is_array($recipient) ? implode(",", $recipient) : $recipient;

		return $this->add_new(
			array("`type`", "`recipient`", "`subject`", "`body`", "`from`", "`auto`", "`timesent`", "`status`", "`timeedit`"),
			array("'%h'", "'%h'", "'%h'", "'%s'", "'%h'", "'%h'", "%d", "'%h'", "%d"),
			array($type, $recipient, $subject, $body, $from, $auto, 0, '0', time())
		);
	}

	/**
	 * Добавляет новую запись
	 *
	 * @param array $fields масив названий полей
	 * @param array $masks массив масок для значений
	 * @param array $values массив значений полей
	 * @return string
	 */
	public function add_new($fields = array(), $masks = array(), $values = array())
	{
		$id = array(
			'master_id' => time(),
			'slave_id' => 0,
		);
		DB::query(
			"SET @".self::TABLE_NAME."_master_id=0, @".self::TABLE_NAME."_slave_id=0;"
		);
		DB::query(
			"INSERT INTO {".self::TABLE_NAME."} (`master_id`, `slave_id`, `id`".(! empty($fields) ? ', ' . implode(', ', $fields) : '').") VALUES (@".self::TABLE_NAME."_master_id:='%d', @".self::TABLE_NAME."_slave_id:=((SELECT IFNULL(MAX(e.slave_id), 0) FROM {postman} AS e WHERE e.master_id='%d') + 1), (CONCAT(@".self::TABLE_NAME."_master_id,'-',@".self::TABLE_NAME."_slave_id))".(! empty($masks) ? ', ' . implode(', ', $masks) : '').");",
			array_merge(array($id["master_id"], $id["master_id"]), $values)
		);
		$id = DB::query_fetch_array(
			"SELECT @".self::TABLE_NAME."_master_id AS master_id, @".self::TABLE_NAME."_slave_id AS slave_id LIMIT 1;"
		);

		return $this->converter_id($id);
	}

	/**
	 * Обновляет запись
	 *
	 * @param mixed(array|string) $id идентификатор уведомления
	 * @param array $fields масив названий полей
	 * @param array $values массив значений полей
	 * @return string
	 */
	public function update($id, $fields = array(), $values = array())
	{
		if(is_string($id))
		{
			if(! $id = $this->converter_id($id))
			{
				return false;
			}
		}
		elseif(is_array($id))
		{
			if(! $this->valid_id($id))
			{
				return false;
			}
		}
		else
		{
			return false;
		}
		if(! $primary_keys = $this->primary_keys())
		{
			return false;
		}
		$where = ' WHERE 1=1'; $keys = array();
		foreach($primary_keys as $primary_key)
		{
			if(! empty($primary_key) && ! empty($id[$primary_key]))
			{
				$where .= ' AND '.$primary_key.'=%d';
				$keys[$primary_key] = $id[$primary_key];
				continue;
			}
			return false;
		}

		if(empty($fields))
		{
			return false;
		}

		$set = " SET ".implode(', ', $fields);
		$values = array_merge($values, $keys);
		DB::query("UPDATE {".self::TABLE_NAME."}". $set ." WHERE master_id='%d' AND slave_id='%d'", $values);

		return true;
	}

	/**
	 * Получает уведомление
	 *
	 * @param mixed(array|string) $id идентификатор уведомления
	 * @return array
	 */
	public function get($id)
	{
		if(is_string($id))
		{
			if(! $id = $this->converter_id($id))
			{
				return false;
			}
		}
		elseif(is_array($id))
		{
			if(! $this->valid_id($id))
			{
				return false;
			}
		}
		else
		{
			return false;
		}
		if(! $primary_keys = $this->primary_keys())
		{
			return false;
		}
		$where = ' WHERE 1=1'; $keys = array();
		foreach($primary_keys as $primary_key)
		{
			if(! empty($primary_key) && ! empty($id[$primary_key]))
			{
				$where .= ' AND '.$primary_key.'=%d';
				$keys[$primary_key] = $id[$primary_key];
				continue;
			}
			return false;
		}
		return DB::query_fetch_array("SELECT * FROM {".self::TABLE_NAME."}".$where." LIMIT 1", $keys);
	}

	/**
	 * Удаляет уведомление
	 *
	 * @param mixed(array|string) $ids идентификатор уведомления
	 * @return boolean
	 */
	public function delete($ids)
	{
		$del = array();
		if(is_string($ids))
		{
			$ids = $this->converter_id($ids);
			if(false === $ids)
			{
				return false;
			}
			$del[] = $this->converter_id($ids);
		}
		elseif(is_array($ids))
		{
			if(! $this->valid_id($ids))
			{
				foreach($ids as $id)
				{
					if(is_string($id))
					{
						$id = $this->converter_id($id);
						if(false === $id)
						{
							continue;
						}
						$del[] = $this->converter_id($id);
					}
					elseif(is_array($id))
					{
						if(! $this->valid_id($id))
						{
							continue;
						}
						$del[] = $this->converter_id($id);
					}
					else
					{
						continue;
					}
				}
			}
			else
			{
				$del[] = $this->converter_id($ids);
			}
		}
		else
		{
			return false;
		}
		if(empty($del))
		{
			return false;
		}

		$where = ' WHERE id IN ('.substr(str_repeat(",'%s'", count($del)), 1).')';

		DB::query("DELETE FROM {".self::TABLE_NAME."}".$where, $del);
		return true;
	}

	/**
	 * Приводит значение переменной к типу, соответстветствующему маске идентификатора уведомления
	 *
	 * @param string $id идентификатор уведомления
	 * @return string
	 */
	public function filter_uid($id)
	{
		return preg_replace("/[^0-9-]/", '', $id);
	}

	/**
	 * Возвращает количество уведомлений, требующих отправки
	 *
	 * @return integer
	 */
	public function count_sent()
	{
		return DB::query_result("SELECT COUNT(*) FROM {".self::TABLE_NAME."} WHERE timesent=%d AND status='%h' AND auto='%h'", 0, 0, 1);
	}
}

/**
 * Postman_exception
 *
 * Исключение для почтовых отправлений
 */
class Postman_db_exception extends Exception{}
