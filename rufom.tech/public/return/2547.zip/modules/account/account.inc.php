<?php
/**
 * Подключение модуля
 *
 * @package    DIAFAN.CMS
 * @author     diafan.ru
 * @version    6.0
 * @license    http://www.diafan.ru/license.html
 * @copyright  Copyright (c) 2003-2018 OOO «Диафан» (http://www.diafan.ru/)
 */

if (! defined('DIAFAN'))
{
	$path = __FILE__;
	while(! file_exists($path.'/includes/404.php'))
	{
		$parent = dirname($path);
		if($parent == $path) exit;
		$path = $parent;
	}
	include $path.'/includes/404.php';
}

/**
 * Account_inc
 */
class Account_inc extends Diafan
{
	/**
	 * @var string имя модуля
	 */
	const MODULE_NAME = 'addons';

	/**
	 * @var object вспомогательный объект модуля
	 */
	private $account = null;

	/**
	 * @var integer метка времени
	 */
	static private $timemarker = 0;

	/**
	 * @var array характеристики текущего пользователя
	 */
	private $user;

	/**
	 * Конструктор класса
	 *
	 * @return void
	 */
	public function __construct(&$diafan)
	{
		parent::__construct($diafan);
		Custom::inc('modules/account/admin/account.admin.inc.php');
		$this->account = new Account_admin_inc($this->diafan);
		self::$timemarker = mktime(23, 59, 0, date("m"), date("d"), date("Y")); // кешируем на сутки
		$this->user = $this->user();
	}

	/**
	 * Доступ к свойствам текущего пользователя
	 *
	 * @return void
	 */
	public function __get($value)
	{
		if(property_exists($this->user, $value))
		{
			return ! empty($this->user->$value) ? $this->user->$value : '';
		}
	}

	/**
	 * Определяет данные о пользователе
	 *
	 * @param boolean $upgrade принудительное обновление
	 * @return object
	 */
	private function user($upgrade = false)
	{
		if($upgrade)
		{
			$this->diafan->_cache->delete("", self::MODULE_NAME);
		}

		$cache_meta = array(
			'time' => self::$timemarker,
			'name' => __METHOD__,
			'addr' => getenv('REMOTE_ADDR', true) ?: getenv('REMOTE_ADDR'),
			'host' => getenv('HTTP_HOST', true) ?: getenv('HTTP_HOST'),
			'token' => $this->account->token,
			'is_auth' => $this->account->is_auth(),
		);

		if(! $result = $this->diafan->_cache->get($cache_meta, self::MODULE_NAME, CACHE_GLOBAL))
		{
			$result = array();
			if($this->account->is_auth())
	    {
				$url = $this->account->uri('users', 'info');
		    if($result = $this->diafan->_client->request($url, $this->account->token))
		    {
					$this->diafan->_client->get_attributes($result, 'name', 'fio', 'mail', 'avatar', 'created', 'cash', 'site_info', 'add_money', 'files_buy');
			    $this->diafan->_client->get_attributes($result["files_buy"], 'buy', 'subscription');
					if(! empty($result["files_buy"]["buy"]))
					{
						foreach($result["files_buy"]["buy"] as &$buy)
						{
							$this->diafan->_client->get_attributes($buy, 'id', 'name', 'link', 'img', 'file_rewrite');
						}
					}
					if(! empty($result["files_buy"]["subscription"]))
					{
						foreach($result["files_buy"]["subscription"] as &$subscription)
						{
							$this->diafan->_client->get_attributes($subscription, 'id', 'name', 'link', 'img', 'file_rewrite', 'subscription', 'auto_subscription', 'price_month');
						}
					}
		    }
	    }
			if(empty($this->diafan->_client->errors) && $result)
			{
				$this->diafan->_cache->save($result, $cache_meta, self::MODULE_NAME, CACHE_GLOBAL);
			}
		}
		if(! $result) $result = new stdClass();
		else $result = (object) $result;
		return $result;
	}
}
