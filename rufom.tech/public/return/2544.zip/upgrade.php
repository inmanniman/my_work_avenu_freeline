<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("ALTER TABLE {shop_cashregister} ADD `payment` VARCHAR(50) NOT NULL DEFAULT ''");

DB::query("ALTER TABLE {custom} ADD `addon_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор дополнения'");


$variable = array('subject_file_sale_message', 'file_sale_message', 'subject_abandonmented_cart', 'message_abandonmented_cart');
$languages = $this->diafan->_languages->all;
if(count($languages) > 1)
{
	if($site_ids = DB::query_fetch_value("SELECT id FROM {site} WHERE module_name='%h' AND trash='0'", 'shop', "id"))
	{
		$site_ids_count = count($site_ids);
		foreach ($variable as $value)
		{
			$new_values = array();
			foreach ($site_ids as $site_id)
			{
				$site_id = $site_ids_count > 1 ? $site_id : 0;
				$default = false;
				foreach ($languages as $language)
				{
					$val = $this->diafan->configmodules($value, "shop", $site_id, $language["id"]);
					if($language["base_site"] == 1)
					{
						$default = $val;
					}
					$new_values[$site_id][$language["id"]] = $this->diafan->configmodules($value, "shop", $site_id, $language["id"]);
				}
				foreach ($languages as $language)
				{
					if(! empty($new_values[$site_id][$language["id"]])) continue;
					$new_values[$site_id][$language["id"]] = $default;
				}
			}
			foreach($new_values as $site_id => $rows)
			{
				foreach($rows as $language_id => $val)
				{
					$this->diafan->configmodules($value, "shop", $site_id, $language_id, $val);
				}
			}
		}
	}
}


DB::query("ALTER TABLE {reviews} CHANGE `element_type` `element_type` ENUM('element', 'cat', 'brand') NOT NULL DEFAULT 'element' COMMENT 'тип элемента модуля'");
DB::query("ALTER TABLE {reviews} ADD `session_id` VARCHAR(64) NOT NULL DEFAULT '' COMMENT 'уникальный идентификатор сессии'");

DB::query("ALTER TABLE {subscription} ADD `send_only_admin` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'отправлять рассылку только администратору: 0 - нет, 1 - да'");

// Для DIAFAN.CMS 6.0.11.5
