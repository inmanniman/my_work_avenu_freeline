<?php
if (! defined('DIAFAN'))
{
	exit;
}


DB::query("ALTER TABLE {shop_cashregister} DROP `payment`");

DB::query("ALTER TABLE {reviews} CHANGE `element_type` `element_type` ENUM('element','cat') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'element' COMMENT 'тип элемента модуля';");
DB::query("ALTER TABLE {reviews} DROP `session_id`;");

DB::query("ALTER TABLE {subscription} DROP `send_only_admin`;");

// Для DIAFAN.CMS 6.0.11.5
