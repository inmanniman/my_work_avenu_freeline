<?php
if (! defined('DIAFAN'))
{
	exit;
}

// DB::query("DROP TABLE {inserts}");
// DB::query("DROP TABLE {inserts_site_rel}");
// DB::query("DELETE FROM {admin} WHERE rewrite='inserts'");
// DB::query("DELETE FROM {modules} WHERE name='inserts'");
//
// DB::query("ALTER TABLE {admin} DROP `icon_name`;");
//
// DB::query("ALTER TABLE {images} CHANGE `folder_num` `folder_num` TINYINT(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'номер папки'");
