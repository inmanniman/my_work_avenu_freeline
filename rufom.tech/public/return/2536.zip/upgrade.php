<?php
if (! defined('DIAFAN'))
{
	exit;
}

// Для DIAFAN.CMS 6.0.10.8
DB::query("ALTER TABLE {addons} ADD `auto_subscription` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'автопродление подписки: 0 - нет, 1 - да'");
// Для DIAFAN.CMS 6.0.10.8
