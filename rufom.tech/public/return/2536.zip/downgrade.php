<?php
if (! defined('DIAFAN'))
{
	exit;
}

// Для DIAFAN.CMS 6.0.10.8
DB::query("ALTER TABLE {addons} DROP auto_subscription;");
// Для DIAFAN.CMS 6.0.10.8
