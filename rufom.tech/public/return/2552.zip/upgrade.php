<?php
if (! defined('DIAFAN'))
{
	exit;
}

$upd_url = parse_url(DB_URL);
$upd_dbname = substr($upd_url['path'], 1);
$upd_table_name = 'shop_files_codes';
if(DB_PREFIX) $upd_table_name = DB_PREFIX.$upd_table_name;
if(DB::query_fetch_array("SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='%h' AND TABLE_NAME='%h'", $upd_dbname, $upd_table_name))
{
	if(DB::query_fetch_array("SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='%h' AND TABLE_NAME='%h' AND COLUMN_NAME='%h' AND DATA_TYPE='%h'", $upd_dbname, $upd_table_name, 'date_finish', 'datetime'))
	{
		DB::query("ALTER TABLE {shop_files_codes} CHANGE `date_finish` `date_finish` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'дата и время окончания действия кода';");
	}
}
// Для DIAFAN.CMS 6.0.12.2
