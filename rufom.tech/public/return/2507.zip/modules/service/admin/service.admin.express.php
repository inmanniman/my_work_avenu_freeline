<?php
/**
 * Администрирование импорт/экспорт записей базы данных
 *
 * @package    DIAFAN.CMS
 * @author     diafan.ru
 * @version    6.0
 * @license    http://www.diafan.ru/license.html
 * @copyright  Copyright (c) 2003-2018 OOO «Диафан» (http://www.diafan.ru/)
 */

if (! defined('DIAFAN'))
{
	$path = __FILE__;
	while(! file_exists($path.'/includes/404.php'))
	{
		$parent = dirname($path);
		if($parent == $path) exit;
		$path = $parent;
	}
	include $path.'/includes/404.php';
}

/**
 * Service_admin_express
 */
class Service_admin_express extends Frame_admin
{
	/**
	 * Выводит контент модуля
	 * @return void
	 */
	public function show()
	{
		$modules = $this->diafan->_service->modules_express();
		if(empty($modules))
		{
			echo '<br />'.'<div class="error">'.$this->diafan->_('Не выявлено модулей доступных для экспорта/импорта. Настрока описания не доступна.').'</div>';
			return;
		}

		if(empty($_SESSION[__CLASS__]["mode_express_choice"]))
		{
			$_SESSION[__CLASS__]["mode_express_choice"] = 'import';
		}
		if(! empty($_SESSION[__CLASS__]["cat_import_choice"]))
		{
			$import_cat = 'cat'.$_SESSION[__CLASS__]["cat_import_choice"].'/';
		}
		else $import_cat = '';
		if(! empty($_SESSION[__CLASS__]["cat_export_choice"]))
		{
			$export_cat = 'cat'.$_SESSION[__CLASS__]["cat_export_choice"].'/';
		}
		else $export_cat = '';
		switch ($_SESSION[__CLASS__]["mode_express_choice"])
		{
			case 'fields':
				$this->diafan->redirect(URL.'fields/');
				break;

			case 'export':
				$this->diafan->redirect(URL.'export/'.$export_cat);
				break;

			case 'import':
			default:
				$this->diafan->redirect(URL.'import/'.$import_cat);
				break;
		}
	}
}
