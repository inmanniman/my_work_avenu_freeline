<?php
/**
 * Обработка POST-запросов в административной части модуля
 *
 * @package    DIAFAN.CMS
 * @author     diafan.ru
 * @version    6.0
 * @license    http://www.diafan.ru/license.html
 * @copyright  Copyright (c) 2003-2018 OOO «Диафан» (http://www.diafan.ru/)
 */

if ( ! defined('DIAFAN'))
{
	$path = __FILE__;
	while(! file_exists($path.'/includes/404.php'))
	{
		$parent = dirname($path);
		if($parent == $path) exit;
		$path = $parent;
	}
	include $path.'/includes/404.php';
}

/**
 * Config_admin_action
 */
class Config_admin_action extends Action_admin
{
	/**
	 * Вызывает обработку Ajax-запросов
	 *
	 * @return void
	 */
	public function init()
	{
		if (! empty($_POST["action"]))
		{
			switch($_POST["action"])
			{
				case 'size':
					$this->size();
					break;
			}
		}
	}

	/**
	 * Определение размера используемых ресурсов
	 *
	 * @return void
	 */
	private function size()
	{
		$time = mktime(23, 59, 0, date("m"), date("d"), date("Y"));
		//кеширование
		$cache_meta = array(
			"name" => "size",
			"time" => $time
		);

		if(! empty($_POST["refresh"]))
		{
			$this->diafan->_cache->delete($cache_meta, 'config');
		}

		if ( ! $result = $this->diafan->_cache->get($cache_meta, 'config'))
		{
			$result = array(
				"files" => 0,
				"db" => 0,
			);

			$files = File::rglob('*');
			foreach($files as $file)
			{
				$result["files"] += File::file_size($file);
			}

			$rows = DB::query_fetch_all("SHOW TABLE STATUS");
			$db_prefix = (defined('DB_PREFIX') ? DB_PREFIX : (defined('DB_PREFIX_DEMO') ? DB_PREFIX_DEMO : ''));
			foreach ($rows as $row)
			{
				if(empty($row["Name"])) continue;
				if(! empty($db_prefix))
				{
					if(! preg_match('/^'.preg_quote($db_prefix, '/').'(.*)/', $row["Name"], $matches))
					{
						continue;
					}
				}
				if(! empty($row["Data_length"])) $result["db"] += $row["Data_length"];
				if(! empty($row["Index_length"])) $result["db"] += $row["Index_length"];
			}

			//сохранение кеша
			$this->diafan->_cache->save($result, $cache_meta, 'config');
		}

		if(! is_array($result)) $result = array();
		if(empty($result["files"]) || $result["files"] < 0) $result["files"] = 0;
		if(empty($result["db"]) || $result["db"] < 0) $result["db"] = 0;
		$this->result["result"]["files_size"] = $this->diafan->convert($result["files"]);
		$this->result["result"]["db_size"] = $this->diafan->convert($result["db"]);
	}
}
