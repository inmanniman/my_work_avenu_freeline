<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("ALTER TABLE {service_express_fields_category} ADD `add_new_items` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'добавить только новые данные, описанные в файле: 0 - нет, 1 - да';");

DB::query("INSERT INTO {admin} (`id`, `parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`) VALUES (NULL, (SELECT e.id  FROM {admin} AS e WHERE e.`rewrite` LIKE 'images' ORDER BY id ASC LIMIT 1), '0', '5', 'Настройки', 'images/config', '0', '0', '', '1', '');");
DB::query("INSERT INTO {config} (`id`, `module_name`, `name`, `lang_id`, `value`, `site_id`) VALUES (NULL, 'images', 'hash_compare', '0', '1', '0');");
DB::query("ALTER TABLE {images} ADD `hash` CHAR(32) NOT NULL DEFAULT '' COMMENT 'хэш файла'");

Custom::inc('includes/config.php');
$config = new Config();
$config->save(array('MOD_DEVELOPER_PROFILER' => false), $this->diafan->_languages->all);
