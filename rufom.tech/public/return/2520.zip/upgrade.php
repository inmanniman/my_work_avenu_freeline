<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("ALTER TABLE {inserts} ADD `date_start` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'дата начала показа'");
DB::query("ALTER TABLE {inserts} ADD `date_finish` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'дата окончания показа'");
DB::query("ALTER TABLE {inserts} ADD `timeedit` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'время последнего изменения в формате UNIXTIME'");
DB::query("ALTER TABLE {inserts} ADD `admin_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'пользователь из таблицы {users}, добавивший или первый отредктировавший товар в административной части'");
DB::query("ALTER TABLE {inserts_site_rel} ADD `trash` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'запись удалена в корзину: 0 - нет, 1 - да'");


// DB::query("ALTER TABLE {ab} ADD `import` ENUM( '0', '1' ) NOT NULL DEFAULT '0' COMMENT 'элемент только что импортирован: 0 - нет, 1 - да'");
// DB::query("ALTER TABLE {ab} ADD `import_id` VARCHAR(100) NOT NULL DEFAULT '' COMMENT 'собственный идентификатор элемента при импорте'");
// DB::query("ALTER TABLE {ab_category} ADD `import` ENUM( '0', '1' ) NOT NULL DEFAULT '0' COMMENT 'категория только что импортирован: 0 - нет, 1 - да'");
// DB::query("ALTER TABLE {ab_category} ADD `import_id` VARCHAR(100) NOT NULL DEFAULT '' COMMENT 'собственный идентификатор категории при импорте'");
// DB::query("ALTER TABLE {ab} ADD `sort` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'подрядковый номер для сортировки'");

DB::query("ALTER TABLE {news} ADD `import` ENUM( '0', '1' ) NOT NULL DEFAULT '0' COMMENT 'элемент только что импортирован: 0 - нет, 1 - да'");
DB::query("ALTER TABLE {news} ADD `import_id` VARCHAR(100) NOT NULL DEFAULT '' COMMENT 'собственный идентификатор элемента при импорте'");
DB::query("ALTER TABLE {news_category} ADD `import` ENUM( '0', '1' ) NOT NULL DEFAULT '0' COMMENT 'категория только что импортирован: 0 - нет, 1 - да'");
DB::query("ALTER TABLE {news_category} ADD `import_id` VARCHAR(100) NOT NULL DEFAULT '' COMMENT 'собственный идентификатор категории при импорте'");
DB::query("ALTER TABLE {news} ADD `sort` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'подрядковый номер для сортировки'");

DB::query("ALTER TABLE {clauses} ADD `import` ENUM( '0', '1' ) NOT NULL DEFAULT '0' COMMENT 'элемент только что импортирован: 0 - нет, 1 - да'");
DB::query("ALTER TABLE {clauses} ADD `import_id` VARCHAR(100) NOT NULL DEFAULT '' COMMENT 'собственный идентификатор элемента при импорте'");
DB::query("ALTER TABLE {clauses_category} ADD `import` ENUM( '0', '1' ) NOT NULL DEFAULT '0' COMMENT 'категория только что импортирован: 0 - нет, 1 - да'");
DB::query("ALTER TABLE {clauses_category} ADD `import_id` VARCHAR(100) NOT NULL DEFAULT '' COMMENT 'собственный идентификатор категории при импорте'");


DB::query("ALTER TABLE {admin} CHANGE `group_id` `group_id` ENUM( '1', '2', '3', '4', '5', '6') NOT NULL DEFAULT '1' COMMENT 'группа'");
DB::query("UPDATE {admin} SET `group_id` = '6' WHERE `rewrite` LIKE '%update%';");
DB::query("UPDATE {admin} SET `sort` = '42' WHERE `rewrite` = 'update';");
DB::query("UPDATE {admin} SET `group_id` = '6', `icon_name` = 'cubes' WHERE `rewrite` LIKE '%addons%';");
$admin_id = DB::query("INSERT INTO {admin} (`parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`, `icon_name`) VALUES
(0, 3, '6', 'Кабинет пользователя', 'account', '1', '0', '', 31, '', 'user');");
DB::query("INSERT INTO {admin} (`parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`, `icon_name`) VALUES
(%d, 0, '6', 'Персональная страница', 'account', '1', '0', '', 1, '', 'user'),
(%d, 0, '6', 'Служба поддержка', 'account/support', '1', '0', '', 2, '', 'user'),
(%d, 0, '6', 'Заказать доработку', 'account/projects', '1', '0', '', 3, '', 'user');", $admin_id, $admin_id, $admin_id);
DB::query("INSERT INTO {modules} (`name`, `module_name`, `site`, `site_page`, `admin`, `title`) VALUES
('account', 'core', '0', '0', '1', 'Кабинет пользователя');");


DB::query("CREATE TABLE {users_token} (
`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'идентификатор',
`user_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор пользователя из таблицы {users}',
`element_type` VARCHAR(10) NOT NULL DEFAULT '' COMMENT 'тип ключа',
`created` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'дата создания',
`token` CHAR(32) NOT NULL DEFAULT '' COMMENT 'электронный ключ',
`date_start` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'дата начала действия электронного ключа',
`date_finish` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'дата окончания действия электронного ключа',
PRIMARY KEY (id)
) CHARSET=utf8 COMMENT 'Электронные ключи пользователей';");


DB::query("ALTER TABLE {shop_cart} ADD `session_id` VARCHAR(64) NOT NULL DEFAULT '' COMMENT 'номер сессии пользователя из таблицы {sessions}, если не заполнен user_id'");
DB::query("ALTER TABLE {shop_cart} ADD `name` VARCHAR(250) NOT NULL DEFAULT '' COMMENT 'имя'");
DB::query("ALTER TABLE {shop_cart} ADD `mail` VARCHAR(64) NOT NULL DEFAULT '' COMMENT 'e-mail'");

DB::query("CREATE TABLE {shop_cart_goods} (
`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'идентификатор',
`cart_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор корзины из таблицы {shop_cart}',
`created` INT(10) UNSIGNED NOT NULL DEFAULT '0',
`good_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
`price_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
`count` DOUBLE NOT NULL DEFAULT '0',
param TEXT,
additional_cost TEXT,
is_file ENUM('0', '1') NOT NULL DEFAULT '0',
`trash` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'запись удалена в корзину: 0 - нет, 1 - да',
PRIMARY KEY (id), KEY cart_id (`cart_id`)
) CHARSET=utf8 COMMENT 'Пользователь, создавший корзину'");

$users = array();
$rows = DB::query_fetch_all("SELECT * FROM {shop_cart}");
foreach($rows as $row)
{
	if(empty($users[$row["user_id"]]))
	{
		$row["cart_id"] = DB::query("INSERT INTO {shop_cart} (user_id) VALUES (%d)", $row["id"]);
		$users[$row["user_id"]] = $row;
	}

	DB::query("INSERT INTO {shop_cart_goods} (cart_id, good_id, `count`, param, additional_cost, is_file, created) VALUES (%d, %d, %f, '%s', '%s', '%d', %d)", $users[$row["user_id"]]["cart_id"], $row["count"], $row["param"], $row["additional_cost"], $row["is_file"], $row["created"]);
}
DB::query("ALTER TABLE {shop_cart} DROP `good_id`, DROP `count`, DROP param, DROP additional_cost, DROP is_file, DROP created");
