/**
 * Редактирование платежных систем, JS-сценарий
 *
 * @package    DIAFAN.CMS
 * @author     diafan.ru
 * @version    6.0
 * @license    http://www.diafan.ru/license.html
 * @copyright  Copyright (c) 2003-2018 OOO «Диафан» (http://www.diafan.ru/)
 */

$("select[name=payment]").change(function() {
	$(".tr_payment").hide();
	$(".tr_payment[payment="+$(this).val()+"]").show();
});
<<<<<<< HEAD
$(".tr_payment").hide();
$(".tr_payment[payment="+$("select[name=payment]").val()+"]").show();
=======
$(".tr_payment[payment="+$("select[name=payment]").val()+"]").show();
>>>>>>> 0b384d64b5605f3ea48b414e43c05a4dbd1628c8
