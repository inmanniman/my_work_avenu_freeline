<?php
/**
 * Брошенные корзины
 * 
 * @package    DIAFAN.CMS
 * @author     diafan.ru
 * @version    6.0
 * @license    http://www.diafan.ru/license.html
 * @copyright  Copyright (c) 2003-2018 OOO «Диафан» (http://www.diafan.ru/)
 */

if (! defined('DIAFAN'))
{
	$path = __FILE__;
	while(! file_exists($path.'/includes/404.php'))
	{
		$parent = dirname($path);
		if($parent == $path) exit;
		$path = $parent;
	}
	include $path.'/includes/404.php';
}

/**
 * Shop_admin_cart
 */
class Shop_admin_cart extends Frame_admin
{
	/**
	 * @var string таблица в базе данных
	 */
	public $table = 'shop_cart';

	/**
	 * @var array поля в списка элементов
	 */
	public $variables_list = array (
		'checkbox' => '',
		'goods' => array(
			'name' => 'Товары',
		),
		'name' => array(
			'name' => 'Пользователь',
			'sql' => true,
		),
		'mail' => array(
			'name' => 'E-mail',
			'sql' => true,
		),
		'user_id' => array(
			'type' => 'none',
			'sql' => true,
		),
		'adapt' => array(
			'class_th' => 'item__th_adapt',
		),
		'separator' => array(
			'class_th' => 'item__th_seporator',
		),
		'actions' => array(
			'trash' => true,
		),
	);

	/**
	 * @var array дополнительные групповые операции
	 */
	public $group_action = array(
		"group_abandonmented_cart_mail" => array(
			'name' => "Отправить письмо",
			'module' => 'shop'
		),
	);

	/**
	 * Выводит список корзин
	 * @return void
	 */
	public function show()
	{
		$this->diafan->list_row();
	}

	/**
	 * Выводит товары в заказе
	 *
	 * @param array $row информация о текущем элементе списка
	 * @param array $var текущее поле
	 * @return string
	 */
	public function list_variable_goods($row, $var)
	{
		if(! isset($this->cache["prepare"]["cart"]))
		{
			$goods = DB::query_fetch_all(
				"SELECT * FROM {shop_cart_goods} WHERE cart_id IN (%s)",
				implode(",", $this->diafan->rows_id)
			);
			$good_ids = array();
			$param_ids = array();
			$param_values = array();
			$this->cache["prepare"]["cart"] = array();
			foreach($goods as $c)
			{
				$this->cache["prepare"]["cart"][$c["cart_id"]][] = $c;
				if(! in_array($c["good_id"], $good_ids))
				{
					$good_ids[] = $c["good_id"];
				}

				$params = unserialize($c["param"]);
				foreach ($params as $id => $value)
				{
					if(! in_array($id, $param_ids))
					{
						$param_ids[] = $id;
					}
					if(! in_array($value, $param_values))
					{
						$param_values[] = $value;
					}
				}
			}
			if($good_ids)
			{
				$this->cache["prepare"]["goods"] = DB::query_fetch_key("SELECT id, [name], article FROM {shop} WHERE id IN (%s)", implode(",", $good_ids), "id");
			}
			if ($param_ids)
			{
				$this->cache["prepare"]["param_names"] = DB::query_fetch_key_value("SELECT id, [name] FROM {shop_param} WHERE id IN (%s)", implode(",", $param_ids), "id", "name");
			}
			if ($param_values)
			{
				$this->cache["prepare"]["select_names"] = DB::query_fetch_key_value("SELECT id, [name] FROM {shop_param_select} WHERE id IN (%s)", implode(",", $param_values), "id", "name");
			}
		}
		if(empty($this->cache["prepare"]["cart"][$row["id"]]))
		{
			return '';
		}
		$text = '<div>';
		foreach($this->cache["prepare"]["cart"][$row["id"]] as $i => $c)
		{
			if(empty($this->cache["prepare"]["goods"][$c["good_id"]]))
			{
				continue;
			}
			$good = $this->cache["prepare"]["goods"][$c["good_id"]];
			if($i)
			{
				$text .= '<br>';
			}
			$text .= date("d.m.Y H:i", $c["created"]).' <a href="'.BASE_PATH_HREF.'shop/edit'.$c["good_id"].'/">'.$good["name"].($good["article"] ? " ".$good["article"] : '');

			$params = unserialize($c["param"]);
			foreach ($params as $id => $value)
			{
				if(! empty($this->cache["prepare"]["param_names"][$id]) && ! empty($this->cache["prepare"]["select_names"][$value]))
				{
					$text .= ', '.$this->cache["prepare"]["param_names"][$id].': '.$this->cache["prepare"]["select_names"][$value];
				}
			}
			$text .= '</a>';
		}
		$text .= '</div>';
		return $text;
	}

	/**
	 * Выводит пользователя
	 *
	 * @param array $row информация о текущем элементе списка
	 * @param array $var текущее поле
	 * @return string
	 */
	public function list_variable_name($row, $var)
	{
		if(! isset($this->cache["prepare"]["users"]))
		{
			foreach($this->diafan->rows as $r)
			{
				$user_ids[] = $r["user_id"];
			}
			if(! empty($user_ids))
			{
				$this->cache["prepare"]["users"] = DB::query_fetch_key(
					"SELECT id, fio, mail FROM {users} AS u WHERE id IN (%s)",
					implode(",", $user_ids),
					"id"
				);
			}
		}
		$user = array();
		$text = '<div class="name">';
		if($row["user_id"] && ! empty($this->cache["prepare"]["users"][$row["user_id"]]))
		{
			$user = $this->cache["prepare"]["users"][$row["user_id"]];
			$text .= '<a href="'.BASE_PATH_HREF.'users/edit'.$row["user_id"].'/">'.($row["name"] ? $row["name"] : $user["fio"]).'</a>';
		}
		else
		{
			$text .= $row["name"];
		}
		$text .= '</div>';
		$text .= '<div class="name">';
		if($row["mail"])
		{
			$text .= $row["mail"];
		}
		elseif(! empty($user["mail"]))
		{
			$text .= $user["mail"];
		}
		$text .= '</div>';
		return $text;
	}

	/**
	 * Выводит e-mail
	 *
	 * @param array $row информация о текущем элементе списка
	 * @param array $var текущее поле
	 * @return string
	 */
	public function list_variable_mail($row, $var)
	{}

	/**
	 * Сопутствующие действия при удалении элемента модуля
	 * @return void
	 */
	public function delete($del_ids)
	{
		$this->diafan->del_or_trash_where("shop_cart_goods", "cart_id IN (".implode(",", $del_ids).")");
	}
}