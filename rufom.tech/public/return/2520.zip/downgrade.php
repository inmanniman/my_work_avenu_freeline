<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("ALTER TABLE {inserts} DROP `date_start`;");
DB::query("ALTER TABLE {inserts} DROP `date_finish`;");
DB::query("ALTER TABLE {inserts} DROP `timeedit`;");
DB::query("ALTER TABLE {inserts} DROP `admin_id`;");
DB::query("ALTER TABLE {inserts_site_rel} DROP `trash`;");


// DB::query("ALTER TABLE {ab} DROP `import`;");
// DB::query("ALTER TABLE {ab} DROP `import_id`;");
// DB::query("ALTER TABLE {ab_category} DROP `import`;");
// DB::query("ALTER TABLE {ab_category} DROP `import_id`;");
// DB::query("ALTER TABLE {ab} DROP `sort`;");

DB::query("ALTER TABLE {news} DROP `import`;");
DB::query("ALTER TABLE {news} DROP `import_id`;");
DB::query("ALTER TABLE {news_category} DROP `import`;");
DB::query("ALTER TABLE {news_category} DROP `import_id`;");
DB::query("ALTER TABLE {news} DROP `sort`;");

DB::query("ALTER TABLE {clauses} DROP `import`;");
DB::query("ALTER TABLE {clauses} DROP `import_id`;");
DB::query("ALTER TABLE {clauses_category} DROP `import`;");
DB::query("ALTER TABLE {clauses_category} DROP `import_id`;");


DB::query("UPDATE {admin} SET `group_id` = '3' WHERE `rewrite` LIKE '%addons%';");
DB::query("UPDATE {admin} SET `group_id` = '3' WHERE `rewrite` LIKE '%update%';");
DB::query("UPDATE {admin} SET `sort` = '31' WHERE `rewrite` = 'update';");
DB::query("DELETE FROM {admin} WHERE `group_id` = '6' AND rewrite='%account%';");
DB::query("ALTER TABLE {admin} CHANGE `group_id` `group_id` ENUM( '1', '2', '3', '4', '5', '6') NOT NULL DEFAULT '1' COMMENT 'группа';");
DB::query("DELETE FROM {modules} WHERE `name` = 'account' AND `module_name`='core';");


DB::query("DROP TABLE {users_token};");


DB::query("ALTER TABLE {shop_cart} ADD `count` DOUBLE NOT NULL DEFAULT '0',
ADD `good_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
ADD `price_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
ADD param TEXT,
ADD additional_cost TEXT,
ADD is_file ENUM('0', '1') NOT NULL DEFAULT '0',
ADD created INT(10) UNSIGNED NOT NULL DEFAULT '0',
DROP `session_id`,
DROP `name`,
DROP `mail`");

$carts = DB::query_fetch_key("SELECT * FROM {shop_cart}", "id");

$rows = DB::query_fetch_all("SELECT * FROM {shop_cart_goods}");

DB::query("TRUNCATE {shop_cart}");

foreach($rows as $row)
{
	if(empty($carts[$row["cart_id"]]["user_id"]))
		continue;

	DB::query("INSERT INTO {shop_cart} (user_id, created, good_id, `count`, param, additional_cost, is_file) VALUES (%d, %d, %d, %f, '%s', '%s', '%d')", $carts[$row["cart_id"]]["user_id"], $row["created"], $row["good_id"], $row["price_id"], $row["count"], $row["param"], $row["additional_cost"], $row["is_file"]);
}

DB::query("DROP TABLE {shop_cart_goods};");
