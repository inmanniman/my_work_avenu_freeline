<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("ALTER TABLE {admin} ADD `icon_name` VARCHAR(30) NOT NULL DEFAULT '' COMMENT 'иконка модуля для административной части сайта'");

$query = "CREATE TABLE {inserts} (
`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'идентификатор',
`name` VARCHAR(100) NOT NULL DEFAULT '' COMMENT 'название',";
foreach($this->diafan->_languages->all as $l)
{
	$query .= "\n`act".$l["id"]."` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'показывать на сайте: 0 - нет, 1 - да',";
}
$query .= "`prefix` ENUM('replace', 'before', 'after') NOT NULL DEFAULT 'replace' COMMENT 'размещение: replace - вместо, before - перед, after - после',
`tag` VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'шаблонный тег',
`text` TEXT COMMENT 'содержание вставки',
`sort` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'подрядковый номер для сортировки',
`trash` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'запись удалена в корзину: 0 - нет, 1 - да',
PRIMARY KEY (id)
) CHARSET=utf8 COMMENT 'Вставки'";

DB::query($query);

DB::query("CREATE TABLE {inserts_site_rel} (
`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'идентификатор',
`element_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор вставки из таблицы {inserts}',
`site_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор страницы сайта из таблицы {site}',
PRIMARY KEY (id),KEY site_id (`site_id`)
) CHARSET=utf8 COMMENT 'Данные о том, на каких страницах выводятся вставки'");


DB::query("INSERT INTO {admin} (group_id, name, rewrite, act, sort, icon_name) VALUES (3, 'Вставки', 'inserts', '1', 41, 'clipboard')");
DB::query("INSERT INTO {modules} (name, module_name, site, admin, title) VALUES ('inserts', 'core', '1', '1', 'Вставки')");

$rows = DB::query_fetch_key("SELECT * FROM {config} WHERE module_name='postman'", "name");
$array = array(
	'SMS' => 'sms',
	'SMS_KEY' => 'bytehand_key',
	'SMS_ID' => 'bytehand_id',
	'SMS_SIGNATURE' => 'bytehand_signature',
	'EMAIL_CONFIG' => 'email',
	'SMTP_MAIL' => 'smtp_mail',
	'SMTP_HOST' => 'smtp_host',
	'SMTP_LOGIN' => 'smtp_login',
	'SMTP_PASSWORD' => 'smtp_password',
	'SMTP_PORT' => 'smtp_port',
);
foreach($array as $k => $v)
{
	if(defined($k) && ! isset($rows[$v]))
	{
		DB::query("INSERT INTO {config} (module_name, name, value) VALUES ('postman', '%s', '%s')", $v, constant($k));
	}
}

DB::query("ALTER TABLE {images} CHANGE `folder_num` `folder_num` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'номер папки'"); 
