<?php
if (! defined('DIAFAN'))
{
	exit;
}
DB::query("ALTER TABLE {postman} DROP `error`;");
DB::query("ALTER TABLE {postman} DROP `trace`;");