<?php
if (! defined('DIAFAN'))
{
	exit;
}
DB::query("ALTER TABLE {postman} ADD `error` TEXT COMMENT 'отчет об ошибке отправления';");
DB::query("ALTER TABLE {postman} ADD `trace` TEXT COMMENT 'трассировка отправления';");