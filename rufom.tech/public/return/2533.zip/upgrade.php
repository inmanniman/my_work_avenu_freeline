<?php
if (! defined('DIAFAN'))
{
	exit;
}

DB::query("ALTER TABLE {shop_order} CHANGE `coupon` `coupon` VARCHAR(255) NOT NULL DEFAULT '';");

