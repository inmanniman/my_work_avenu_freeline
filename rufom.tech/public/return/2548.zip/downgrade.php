<?php
if (! defined('DIAFAN'))
{
	exit;
}


if($admin_row_id = DB::query_result("SELECT id FROM {admin} WHERE parent_id=%d AND `rewrite`='%h' LIMIT 1", 0, 'account'))
{
	DB::query("DELETE FROM {admin} WHERE parent_id=%d AND `rewrite`='%h' LIMIT 1", $admin_row_id, 'account/config');
}

// Для DIAFAN.CMS 6.0.11.9
