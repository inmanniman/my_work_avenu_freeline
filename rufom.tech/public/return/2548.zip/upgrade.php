<?php
if (! defined('DIAFAN'))
{
	exit;
}

if($admin_row = DB::query_fetch_array("SELECT id, parent_id, group_id FROM {admin} WHERE parent_id=%d AND `rewrite`='%h' LIMIT 1", 0, 'account'))
{
	$admin_row_id = DB::query(
		"INSERT INTO {admin} (parent_id, count_children, group_id, `name`, `rewrite`, act, `add`, add_name, sort, docs, icon_name)"
		." VALUES (%d, %d, %d, '%h', '%h', '%d', '%d', '%h', %d, '%h', '%h')",
		$admin_row["id"], 0, $admin_row["group_id"], 'Настройки', 'account/config', 1, 0, '', 4, '', 'user');
	if($admin_row_id)
	{
		$admin_row["count_children"] += 1;
		DB::query("UPDATE {admin} SET count_children=%d WHERE id=%d LIMIT 1", $admin_row["count_children"], $admin_row["id"]);
	}
}

// Для DIAFAN.CMS 6.0.11.9
